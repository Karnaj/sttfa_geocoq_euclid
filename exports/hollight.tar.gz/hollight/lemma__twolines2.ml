(*lemma__twolines2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((neq A) B) ==> (((neq C) D) ==> ((((col P) A) B) ==> ((((col P) C) D) ==> ((((col Q) A) B) ==> ((((col Q) C) D) ==> ((mat_not ((mat_and (((col A) C) D)) (((col B) C) D))) ==> ((eq P) Q)))))))))))))`*)
let lemma__twolines2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(P : mat_Point)` 
     (GEN `(Q : mat_Point)` 
      (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
       (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
        (DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
         (DISCH `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
          (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
           (DISCH `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
            (DISCH `mat_not ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
             (MP  
              (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
               (MP  
                (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (CONV_CONV_rule `(((neq (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> ((eq (P : mat_Point)) (Q : mat_Point))` 
                   (DISCH `mat_not ((neq (P : mat_Point)) (Q : mat_Point))` 
                    (MP  
                     (CONV_CONV_rule `((mat_not ((eq (P : mat_Point)) (Q : mat_Point))) ==> mat_false) ==> ((eq (P : mat_Point)) (Q : mat_Point))` 
                      (SPEC `(eq (P : mat_Point)) (Q : mat_Point)` (nNPP))
                     ) (DISCH `mat_not ((eq (P : mat_Point)) (Q : mat_Point))` 
                        (MP  
                         (DISCH `mat_false` 
                          (MP  
                           (DISCH `(((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false)` 
                            (MP  
                             (SPEC `mat_false` (false__ind)
                             ) (ASSUME `mat_false`))
                           ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                 (ASSUME `mat_not ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                 )
                                ) (MP  
                                   (MP  
                                    (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (conj))
                                    ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                    )
                                   ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                   ))))))
                         ) (MP  
                            (CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (Q : mat_Point))) ==> mat_false` 
                             (ASSUME `mat_not ((neq (P : mat_Point)) (Q : mat_Point))`
                             )
                            ) (ASSUME `mat_not ((eq (P : mat_Point)) (Q : mat_Point))`
                            ))))))
                  ) (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                     (MP  
                      (DISCH `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                       (MP  
                        (DISCH `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                         (MP  
                          (DISCH `((col (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                           (MP  
                            (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                             (MP  
                              (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                               (MP  
                                (DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                 (MP  
                                  (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                   (MP  
                                    (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (DISCH `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                       (MP  
                                        (DISCH `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `(((eq (Q : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                           (DISCH `mat_not ((eq (Q : mat_Point)) (C : mat_Point))` 
                                            (MP  
                                             (DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                              (MP  
                                               (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `(((eq (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> mat_false` 
                                                  (DISCH `mat_not ((eq (B : mat_Point)) (A : mat_Point))` 
                                                   (MP  
                                                    (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((col (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                               (MP  
                                                                (DISCH `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (CONV_CONV_rule `((((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                  ) (
                                                                  DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `(mat_not ((eq (Q : mat_Point)) (C : mat_Point))) ==> (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   ASSUME `mat_not ((eq (Q : mat_Point)) (C : mat_Point))`
                                                                   ))))))
                                                                ) (MP  
                                                                   (DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                   ))))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `((((nCol (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                 ) (DISCH `((nCol (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                            ) (MP  
                                                               (DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                  ))))
                                                          ) (MP  
                                                             (DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                                                                  (SPEC `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(Q : mat_Point)` 
                                                                 (SPEC `(P : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__collinearorder
                                                                   )))
                                                                ) (ASSUME `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (CONV_CONV_rule `((((nCol (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                            (SPEC `(Q : mat_Point)` 
                                                             (SPEC `(P : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (not__nCol__Col
                                                               ))))
                                                           ) (DISCH `((nCol (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(Q : mat_Point)` 
                                                                 (SPEC `(P : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (col__nCol__False
                                                                   )))
                                                                ) (ASSUME `((nCol (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                )
                                                               ) (MP  
                                                                  (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (A : mat_Point))) ==> (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    ))
                                                                  ) (
                                                                  ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`
                                                                  ))))))
                                                      ) (MP  
                                                         (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                             (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                              (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                               (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(Q : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (lemma__collinearorder
                                                               )))
                                                            ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                           (SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                            (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                             (DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                  (SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(P : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__collinearorder
                                                             )))
                                                          ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                          )))))
                                                 ) (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                        (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__equalitysymmetric
                                                          ))
                                                        ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`
                                                        )))))
                                               ) (MP  
                                                  (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                       (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                             (SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                   (SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (lemma__collinearorder
                                                        )))
                                                     ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                     ))))
                                             ) (MP  
                                                (CONV_CONV_rule `((((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (not__nCol__Col))))
                                                ) (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (col__nCol__False)))
                                                     ) (ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                     )
                                                    ) (MP  
                                                       (CONV_CONV_rule `(mat_not ((eq (Q : mat_Point)) (C : mat_Point))) ==> (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(Q : mat_Point)` 
                                                              (lemma__collinear4
                                                              ))))
                                                          ) (ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                          )
                                                         ) (ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                         ))
                                                       ) (ASSUME `mat_not ((eq (Q : mat_Point)) (C : mat_Point))`
                                                       )))))))
                                          ) (DISCH `(eq (Q : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                               (MP  
                                                (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                               (MP  
                                                                (DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (P : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (C : mat_Point))) ==> (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (P : mat_Point)) (C : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (C : mat_Point))) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (P : mat_Point)) (C : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (Q : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (C : mat_Point)) ==> (((eq (C : mat_Point)) (Q : mat_Point)) ==> ((eq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__trans
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (C : mat_Point)) ==> ((eq (C : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                  ) (
                                                                  MP  
                                                                  (DISCH `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                  ))))
                                                                ) (MP  
                                                                   (DISCH `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                   ))))
                                                              ) (MP  
                                                                 (DISCH `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point)))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (P : mat_Point))) (((col (A : mat_Point)) (P : mat_Point)) (C : mat_Point)))))`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                            ) (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (C : mat_Point)) ==> ((((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (Q : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) ==> ((((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (C : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (x : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. ((((col (Q0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (Q0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (Q0 : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (Q0 : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (Q0 : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (Q0 : mat_Point)) ==> ((((col (P : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (Q0 : mat_Point)) (C : mat_Point)) ==> ((((col (Q0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (Q0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (Q0 : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (Q0 : mat_Point)) ==> ((((col (A : mat_Point)) (Q0 : mat_Point)) (P : mat_Point)) ==> ((((col (Q0 : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                                )
                                                               ) (ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (C : mat_Point)) ==> ((((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (Q : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) ==> ((((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) ==> ((((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (C : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (x : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. ((((col (Q0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (Q0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (Q0 : mat_Point)) ==> ((((col (D : mat_Point)) (C : mat_Point)) (Q0 : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (Q0 : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((col (B : mat_Point)) (P : mat_Point)) (Q0 : mat_Point)) ==> ((((col (P : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (Q0 : mat_Point)) (C : mat_Point)) ==> ((((col (Q0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (Q0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (Q0 : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (Q0 : mat_Point)) ==> ((((col (A : mat_Point)) (Q0 : mat_Point)) (P : mat_Point)) ==> ((((col (Q0 : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                )
                                                               ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                               )
                                                              ) (ASSUME `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                              )
                                                             ) (ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                               (SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))))` 
                                                                (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)))))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(P : mat_Point)` 
                                                               (SPEC `(Q : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (lemma__collinearorder
                                                                 )))
                                                              ) (ASSUME `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (CONV_CONV_rule `((((nCol (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                          (SPEC `(P : mat_Point)` 
                                                           (SPEC `(Q : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (not__nCol__Col)
                                                            )))
                                                         ) (DISCH `((nCol (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(P : mat_Point)` 
                                                               (SPEC `(Q : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (col__nCol__False
                                                                 )))
                                                              ) (ASSUME `((nCol (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)`
                                                              )
                                                             ) (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(P : mat_Point)` 
                                                                   (SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                ))))))
                                                    ) (MP  
                                                       (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                           (SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                            (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                             (DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                  (SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(P : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__collinearorder
                                                             )))
                                                          ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                         (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                          (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                           (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                               (SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                (SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(Q : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (lemma__collinearorder
                                                           )))
                                                        ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                        ))))
                                                ) (MP  
                                                   (DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                        (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                              (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                               (DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)))))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(Q : mat_Point)` 
                                                        (SPEC `(P : mat_Point)` 
                                                         (lemma__collinearorder
                                                         )))
                                                      ) (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                      ))))
                                              ) (MP  
                                                 (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                      (SPEC `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                       (DISCH `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                            (SPEC `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                  (SPEC `((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)))))`
                                                   ))
                                                 ) (MP  
                                                    (SPEC `(P : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(D : mat_Point)` 
                                                       (lemma__collinearorder
                                                       )))
                                                    ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                    ))))))
                                        ) (MP  
                                           (DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))))` 
                                                (SPEC `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                 (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                      (SPEC `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                       (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                            (SPEC `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                  (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(Q : mat_Point)` 
                                                 (lemma__collinearorder)))
                                              ) (ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (CONV_CONV_rule `((((nCol (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(Q : mat_Point)` 
                                             (not__nCol__Col))))
                                         ) (DISCH `((nCol (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(Q : mat_Point)` 
                                                 (col__nCol__False)))
                                              ) (ASSUME `((nCol (Q : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                              )
                                             ) (MP  
                                                (MP  
                                                 (MP  
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(C : mat_Point)` 
                                                    (SPEC `(Q : mat_Point)` 
                                                     (SPEC `(P : mat_Point)` 
                                                      (lemma__collinear4))))
                                                  ) (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                  )
                                                 ) (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                 )
                                                ) (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                ))))))
                                    ) (MP  
                                       (DISCH `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))))` 
                                            (SPEC `((col (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                             (DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)))` 
                                                  (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                        (SPEC `((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                         (DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                               (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (P : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (C : mat_Point)))))`
                                         ))
                                       ) (MP  
                                          (SPEC `(Q : mat_Point)` 
                                           (SPEC `(P : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (lemma__collinearorder)))
                                          ) (ASSUME `((col (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                          ))))
                                  ) (MP  
                                     (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                         (SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                          (SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                           (DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                 (DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                      (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                       (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                            (SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                             (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                              (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))))`
                                             ))))
                                       ) (ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))))`
                                       ))
                                     ) (MP  
                                        (SPEC `(Q : mat_Point)` 
                                         (SPEC `(P : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (lemma__collinearorder)))
                                        ) (ASSUME `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                        ))))
                                ) (MP  
                                   (CONV_CONV_rule `((((nCol (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                                    (SPEC `(Q : mat_Point)` 
                                     (SPEC `(P : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (not__nCol__Col))))
                                   ) (DISCH `((nCol (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                      (MP  
                                       (MP  
                                        (SPEC `(Q : mat_Point)` 
                                         (SPEC `(P : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (col__nCol__False)))
                                        ) (ASSUME `((nCol (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                        )
                                       ) (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(Q : mat_Point)` 
                                             (SPEC `(P : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (lemma__collinear4))))
                                            ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                            )
                                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                           )
                                          ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                          ))))))
                              ) (MP  
                                 (DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                     (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))` 
                                      (SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                       (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                           (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))` 
                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                             (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                 (SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))` 
                                                  (SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                   (DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                       (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                        (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                         (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                          (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)))))`
                                   ))
                                 ) (MP  
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (SPEC `(Q : mat_Point)` 
                                       (lemma__collinearorder)))
                                    ) (ASSUME `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                    ))))
                            ) (MP  
                               (DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))` 
                                (MP  
                                 (MP  
                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                   (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                    (SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                     (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                         (SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                           (DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                               (SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                (SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                 (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                     (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                      (SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                       (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                        (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                                             ))))
                                       ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))))`
                                       ))))
                                 ) (ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)))))`
                                 ))
                               ) (MP  
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(P : mat_Point)` 
                                     (lemma__collinearorder)))
                                  ) (ASSUME `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                  ))))
                          ) (MP  
                             (CONV_CONV_rule `((((nCol (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                              (SPEC `(Q : mat_Point)` 
                               (SPEC `(P : mat_Point)` 
                                (SPEC `(C : mat_Point)` (not__nCol__Col))))
                             ) (DISCH `((nCol (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(Q : mat_Point)` 
                                   (SPEC `(P : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (col__nCol__False)))
                                  ) (ASSUME `((nCol (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                  )
                                 ) (MP  
                                    (MP  
                                     (MP  
                                      (SPEC `(Q : mat_Point)` 
                                       (SPEC `(P : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (lemma__collinear4))))
                                      ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                      )
                                     ) (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                     )
                                    ) (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                    ))))))
                        ) (MP  
                           (DISCH `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                               (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))))` 
                                (SPEC `((col (C : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (C : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                 (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                     (SPEC `(mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                      (SPEC `((col (C : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                       (DISCH `(mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                           (SPEC `(mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                            (SPEC `((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                 (SPEC `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                  (SPEC `((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                    (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (Q : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (Q : mat_Point))) ((mat_and (((col (D : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and (((col (Q : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)))))`
                             ))
                           ) (MP  
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(Q : mat_Point)` 
                                 (lemma__collinearorder)))
                              ) (ASSUME `((col (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                              ))))
                      ) (MP  
                         (DISCH `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)))))` 
                          (MP  
                           (MP  
                            (SPEC `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                             (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))))` 
                              (SPEC `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                               (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                   (SPEC `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                                    (SPEC `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                     (DISCH `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                         (SPEC `(mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                          (SPEC `((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                               (SPEC `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                (SPEC `((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                  (ASSUME `((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                  )))
                                             ) (ASSUME `(mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)))`
                                       ))))
                                 ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point))))`
                                 ))))
                           ) (ASSUME `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (C : mat_Point))) ((mat_and (((col (P : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (P : mat_Point)))))`
                           ))
                         ) (MP  
                            (SPEC `(D : mat_Point)` 
                             (SPEC `(C : mat_Point)` 
                              (SPEC `(P : mat_Point)` (lemma__collinearorder)
                              ))
                            ) (ASSUME `((col (P : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                            ))))))
                ) (MP  
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(C : mat_Point)` (lemma__inequalitysymmetric))
                   ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`)))
              ) (MP  
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric))
                 ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))))))))))
    ))))
 ;;


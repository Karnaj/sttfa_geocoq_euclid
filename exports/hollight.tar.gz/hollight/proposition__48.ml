(*proposition__48 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! K : mat_Point. (! L : mat_Point. (! M : mat_Point. ((((triangle A) B) C) ==> (((((sQ A) B) F) G) ==> (((((sQ A) C) K) H) ==> (((((sQ B) C) E) D) ==> ((((betS B) M) C) ==> ((((betS E) L) D) ==> (((((((((eF A) B) F) G) B) M) L) D) ==> (((((((((eF A) C) K) H) M) C) E) L) ==> (((((rE M) C) E) L) ==> (((per B) A) C))))))))))))))))))))`*)
let proposition__48 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (GEN `(K : mat_Point)` 
         (GEN `(L : mat_Point)` 
          (GEN `(M : mat_Point)` 
           (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
            (DISCH `(((sQ (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
             (DISCH `(((sQ (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
              (DISCH `(((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
               (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                (DISCH `((betS (E : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                 (DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)` 
                  (DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                   (DISCH `(((rE (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)` 
                    (MP  
                     (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                      (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                           (MP  
                            (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                             (MP  
                              (DISCH `ex (\ R : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                   (SPEC `\ R : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(R : mat_Point)` 
                                    (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (A : mat_Point))))))) ==> (((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                             (DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                              (MP  
                                               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                  (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> (((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                     (DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(neq (B : mat_Point)) (R : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(neq (R : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((nCol (R : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (DISCH `ex (\ Q : mat_Point. ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((per (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((tS (x : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Q : mat_Point. ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                  ) (
                                                                  GEN `(Q : mat_Point)` 
                                                                  (DISCH `(mat_and (((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ c : mat_Point. ((mat_and (((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (A : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. ((mat_and (((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ c : mat_Point. ((mat_and (((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ f : mat_Point. (ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (g : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ f : mat_Point. (ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ f : mat_Point. (ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(f : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (x : mat_Point))) ((mat_and ((((tS (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    SPEC `(((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ k : mat_Point. (ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (x : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (x : mat_Point)) (h : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ k : mat_Point. (ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ k : mat_Point. (ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(k : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (x : mat_Point))) ((mat_and ((((tS (x : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(h : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))` 
                                                                    (
                                                                    SPEC `(((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ e : mat_Point. (ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (x : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (x : mat_Point)) (d : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. (ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. (ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(e : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (x : mat_Point))) ((mat_and ((((tS (x : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) ==> (((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (g : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (h : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (x : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (x : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (x : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (x : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(m : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (x : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (x : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (x : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(l : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (e : mat_Point)) (l : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (m : mat_Point))) ((mat_or ((eq (B : mat_Point)) (c : mat_Point))) ((mat_or ((eq (m : mat_Point)) (c : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (B : mat_Point)) (c : mat_Point)) (m : mat_Point))))))) ==> (((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (m : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((pG (c : mat_Point)) (e : mat_Point)) (l : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((rE (c : mat_Point)) (e : mat_Point)) (l : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((rE (e : mat_Point)) (l : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((rE (l : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((rE (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equaltorightisright
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) ==> ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) ==> ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point))))))`
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__08
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__48A
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__paste5
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (l : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((rE (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((rE (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    lemma__rectanglerotate
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((rE (l : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__rectanglerotate
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((rE (e : mat_Point)) (l : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__rectanglerotate
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((rE (c : mat_Point)) (e : mat_Point)) (l : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__PGrectangle
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (c : mat_Point)) (e : mat_Point)) (l : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (m : mat_Point)) (c : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__PGrotate
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (m : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((col (m : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((col (m : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((col (c : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (c : mat_Point)) (m : mat_Point))) (((col (c : mat_Point)) (m : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (c : mat_Point))) ((mat_or ((eq (m : mat_Point)) (c : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (B : mat_Point)) (c : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (c : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (B : mat_Point)) (c : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (m : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (B : mat_Point)) (c : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (B : mat_Point)) (c : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (m : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (m : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point))) ((mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point))) ((mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point))) ((mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (c : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (c : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point))) ((mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) ==> (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point))) ((mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point))) ((mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point))) ((mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (c : mat_Point)) (c : mat_Point)) (k : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (c : mat_Point)) (c : mat_Point)) (k : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point))) ((mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) ==> (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) ==> (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((per (B : mat_Point)) (F : mat_Point)) (G : mat_Point))) (((per (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (H : mat_Point)) (A : mat_Point))) ((mat_and (((per (H : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((per (A : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_and (((per (C : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((per (K : mat_Point)) (H : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((per (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((per (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((per (E : mat_Point)) (D : mat_Point)) (B : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (g : mat_Point)) (A : mat_Point))) ((mat_and (((per (g : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (f : mat_Point))) ((mat_and (((per (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) (((per (f : mat_Point)) (g : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point))) ((mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (c : mat_Point)) (h : mat_Point)) (A : mat_Point))) ((mat_and (((per (h : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((per (A : mat_Point)) (c : mat_Point)) (k : mat_Point))) ((mat_and (((per (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) (((per (k : mat_Point)) (h : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point))) ((mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point))) ((mat_and (((per (d : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((per (B : mat_Point)) (c : mat_Point)) (e : mat_Point))) ((mat_and (((per (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((per (e : mat_Point)) (d : mat_Point)) (B : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)) (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)) (M : mat_Point)) (C : mat_Point)) (E : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(l : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__squaresequal
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__squaresequal
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (C : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ m : mat_Point. (ex (\ l : mat_Point. ((mat_and ((((pG (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((mat_and (((betS (B : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((mat_and ((((pG (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))) ((mat_and (((betS (d : mat_Point)) (l : mat_Point)) (e : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)) (B : mat_Point)) (m : mat_Point)) (l : mat_Point)) (d : mat_Point))) ((((((((eF (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)) (m : mat_Point)) (c : mat_Point)) (e : mat_Point)) (l : mat_Point))))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(k : mat_Point)` 
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__47
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (g : mat_Point)) (B : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (h : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(h : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ e : mat_Point. (ex (\ d : mat_Point. ((mat_and ((((sQ (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and ((((tS (d : mat_Point)) (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((((pG (B : mat_Point)) (c : mat_Point)) (e : mat_Point)) (d : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__46
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ k : mat_Point. (ex (\ h : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point))) ((mat_and ((((tS (h : mat_Point)) (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((((pG (A : mat_Point)) (c : mat_Point)) (k : mat_Point)) (h : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__46
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (c : mat_Point))) ((mat_and ((neq (A : mat_Point)) (c : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (c : mat_Point)) (B : mat_Point))) ((neq (c : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ f : mat_Point. (ex (\ g : mat_Point. ((mat_and ((((sQ (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point))) ((mat_and ((((tS (g : mat_Point)) (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((((pG (A : mat_Point)) (B : mat_Point)) (f : mat_Point)) (g : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__46
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (c : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (c : mat_Point)) (A : mat_Point))) (((nCol (c : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ c : mat_Point. ((mat_and (((out (A : mat_Point)) (Q : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (A : mat_Point))) ((neq (Q : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `ex (\ Q : mat_Point. ((mat_and (((per (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((tS (Q : mat_Point)) (B : mat_Point)) (R : mat_Point)) (C : mat_Point))))`
                                                                 ))
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__11B
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                  )))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (R : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((nCol (R : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   ))))
                                                           ) (MP  
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(R : mat_Point)` 
                                                                 (nCol__notCol
                                                                 )))
                                                              ) (MP  
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(R : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (R : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                         ) (MP  
                                                            (SPEC `(R : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (lemma__inequalitysymmetric
                                                              ))
                                                            ) (ASSUME `(neq (B : mat_Point)) (R : mat_Point)`
                                                            )))
                                                       ) (MP  
                                                          (DISCH `(mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (B : mat_Point)) (R : mat_Point)` 
                                                              (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                               (SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(neq (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (R : mat_Point)))`
                                                            ))
                                                          ) (MP  
                                                             (SPEC `(R : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (lemma__betweennotequal
                                                                )))
                                                             ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                             )))))
                                                    ) (MP  
                                                       (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                        (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                           (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                            (or__intror))
                                                          ) (MP  
                                                             (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                              (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                               (or__introl))
                                                             ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                             ))))))
                                                 ) (SPEC `(B : mat_Point)` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (eq__refl))))
                                               ) (MP  
                                                  (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                      (SPEC `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                        (DISCH `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                            (SPEC `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                             (SPEC `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                              (DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                  (SPEC `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                   (SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(R : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (lemma__collinearorder
                                                        )))
                                                     ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                     )))))
                                            ) (MP  
                                               (SPEC `(mat_or ((eq (B : mat_Point)) (R : mat_Point))) ((mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (A : mat_Point)))))` 
                                                (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                 (or__intror))
                                               ) (MP  
                                                  (SPEC `(mat_or ((eq (A : mat_Point)) (R : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (A : mat_Point))))` 
                                                   (SPEC `(eq (B : mat_Point)) (R : mat_Point)` 
                                                    (or__intror))
                                                  ) (MP  
                                                     (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (A : mat_Point)))` 
                                                      (SPEC `(eq (A : mat_Point)) (R : mat_Point)` 
                                                       (or__intror))
                                                     ) (MP  
                                                        (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((betS (B : mat_Point)) (R : mat_Point)) (A : mat_Point))` 
                                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                          (or__intror))
                                                        ) (MP  
                                                           (SPEC `((betS (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                             (or__introl))
                                                           ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                           )))))))))
                                      ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (R : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                ))
                              ) (MP  
                                 (MP  
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (lemma__extension))))
                                  ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                  )
                                 ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                 )))
                            ) (MP  
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (lemma__inequalitysymmetric))
                               ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                               )))
                          ) (MP  
                             (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                 (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                   (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                             (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                               (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                    (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                          (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                           (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                            (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                     ))))
                               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                               ))
                             ) (MP  
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` (lemma__NCdistinct)
                                  ))
                                ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                ))))
                        ) (MP  
                           (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                 (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                            (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                  (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                   (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                        (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                          (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                             ))
                           ) (MP  
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
                              ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                              )))))
                     ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     )))))))))))))))))))))
 ;;


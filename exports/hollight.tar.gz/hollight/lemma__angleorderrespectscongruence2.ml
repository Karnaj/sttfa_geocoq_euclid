(*lemma__angleorderrespectscongruence2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((ltA A) B) C) D) E) F) ==> (((((((congA a) b) c) A) B) C) ==> ((((((ltA a) b) c) D) E) F)))))))))))`*)
let lemma__angleorderrespectscongruence2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(a : mat_Point)` 
       (GEN `(b : mat_Point)` 
        (GEN `(c : mat_Point)` 
         (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
          (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
             (DISCH `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))))` 
              (MP  
               (MP  
                (SPEC `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (x : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))))) ==> (return : bool)))` 
                  (SPEC `\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(P : mat_Point)` 
                   (DISCH `ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))` 
                    (MP  
                     (MP  
                      (SPEC `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))) ==> (return : bool)))` 
                        (SPEC `\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(Q : mat_Point)` 
                         (DISCH `ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))` 
                          (MP  
                           (MP  
                            (SPEC `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))) ==> (return : bool)))` 
                              (SPEC `\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(R : mat_Point)` 
                               (DISCH `(mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                   (SPEC `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))` 
                                    (SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                     (DISCH `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                         (SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))` 
                                          (SPEC `((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                           (DISCH `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                               (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                (SPEC `((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                 (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))) ==> ((((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                      (DISCH `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                       (ASSUME `(((((ltA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(P : mat_Point)` 
                                                         (CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))))` 
                                                          (SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__intro))))
                                                        ) (MP  
                                                           (SPEC `(Q : mat_Point)` 
                                                            (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (P : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point))))))))))` 
                                                             (SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (P : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__intro))))
                                                           ) (MP  
                                                              (SPEC `(R : mat_Point)` 
                                                               (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (x : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))) ==> (ex (\ V : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))` 
                                                                (SPEC `\ V : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (V : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__intro)
                                                                 )))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))` 
                                                                   (SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                  ) (
                                                                  ASSUME `((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point)`
                                                                  )
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)`
                                                                    ))))))))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `(Q : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(c : mat_Point)` 
                                                              (SPEC `(b : mat_Point)` 
                                                               (SPEC `(a : mat_Point)` 
                                                                (lemma__equalanglestransitive
                                                                )))))))))
                                                       ) (ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)`
                                                      )))))
                                             ) (ASSUME `(mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point)))`
                                       ))))
                                 ) (ASSUME `(mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))`
                                 ))))
                           ) (ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))`
                           ))))
                     ) (ASSUME `ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))`
                     ))))
               ) (ASSUME `ex (\ P : mat_Point. (ex (\ Q : mat_Point. (ex (\ R : mat_Point. ((mat_and (((betS (P : mat_Point)) (Q : mat_Point)) (R : mat_Point))) ((mat_and (((out (E : mat_Point)) (D : mat_Point)) (P : mat_Point))) ((mat_and (((out (E : mat_Point)) (F : mat_Point)) (R : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (Q : mat_Point))))))))))`
               )))
            ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
            ))))))))))))
 ;;


(*lemma__TTflip2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (((((((((tT A) B) C) D) E) F) G) H) ==> ((((((((tT A) B) C) D) H) G) F) E)))))))))`*)
let lemma__TTflip2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (DISCH `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
         (MP  
          (CONV_CONV_rule `((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
           (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))))` 
            (MP  
             (MP  
              (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))))) ==> (return : bool)))` 
                (SPEC `\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(J : mat_Point)` 
                 (DISCH `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))` 
                  (MP  
                   (MP  
                    (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                     (SPEC `(mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))` 
                      (SPEC `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                       (DISCH `(mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                           (SPEC `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                            (SPEC `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                             (DISCH `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                (DISCH `ex (\ K : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)))))) ==> (return : bool)))` 
                                     (SPEC `\ K : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point))))` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (ex__ind))))
                                   ) (GEN `(K : mat_Point)` 
                                      (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                          (SPEC `(mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point))` 
                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point)` 
                                            (DISCH `(mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                (SPEC `(((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                 (SPEC `(((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(neq (F : mat_Point)) (J : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
                                                             (MP  
                                                              (DISCH `ex (\ L : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (F : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ L : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                                                   (SPEC `\ L : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                   ))
                                                                 ) (GEN `(L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (L : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (L : mat_Point)) (H : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (L : mat_Point)) (L : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (J : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (X : mat_Point)))))) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (X : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (X : mat_Point)))))) ==> ((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (X : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (X : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (L : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (H : mat_Point)) (L : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (J : mat_Point)) (H : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (L : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (H : mat_Point)) (L : mat_Point)) (L : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (L : mat_Point)) (H : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (L : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (L : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (L : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (L : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (L : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (L : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (L : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (L : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (L : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (L : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (L : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (E : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `ex (\ L : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (L : mat_Point))) ((((cong (G : mat_Point)) (L : mat_Point)) (F : mat_Point)) (E : mat_Point))))`
                                                                ))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(neq (H : mat_Point)) (G : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (SPEC `(F : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (lemma__inequalitysymmetric
                                                                 ))
                                                               ) (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (DISCH `(mat_and ((neq (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                 (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point))` 
                                                                  (SPEC `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((neq (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point)))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(J : mat_Point)` 
                                                                 (SPEC `(F : mat_Point)` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (lemma__betweennotequal
                                                                   )))
                                                                ) (ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (SPEC `(H : mat_Point)` 
                                                            (SPEC `(G : mat_Point)` 
                                                             (lemma__inequalitysymmetric
                                                             ))
                                                           ) (ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                           )))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(H : mat_Point)` 
                                                           (SPEC `(G : mat_Point)` 
                                                            (SPEC `(J : mat_Point)` 
                                                             (SPEC `(F : mat_Point)` 
                                                              (axiom__nocollapse
                                                              ))))
                                                          ) (ASSUME `(neq (F : mat_Point)) (J : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (DISCH `(mat_and ((neq (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (F : mat_Point)) (J : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point))` 
                                                            (SPEC `(neq (F : mat_Point)) (J : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (F : mat_Point)) (J : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                 (SPEC `(neq (E : mat_Point)) (J : mat_Point)` 
                                                                  (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                   (DISCH `(neq (E : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((neq (E : mat_Point)) (J : mat_Point)))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(J : mat_Point)` 
                                                           (SPEC `(F : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (lemma__betweennotequal
                                                             )))
                                                          ) (ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                          ))))))
                                              ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)))`
                                        ))))
                                  ) (ASSUME `ex (\ K : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((lt (E : mat_Point)) (J : mat_Point)) (A : mat_Point)) (K : mat_Point)))))`
                                  )))
                               ) (ASSUME `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                               ))))
                         ) (ASSUME `(mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))`
                         ))))
                   ) (ASSUME `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))`
                   ))))
             ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))))`
             )))
          ) (ASSUME `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
          ))))))))))
 ;;


(*lemma__ray1 :  |- `! A : mat_Point. (! B : mat_Point. (! P : mat_Point. ((((out A) B) P) ==> ((mat_or (((betS A) P) B)) ((mat_or ((eq B) P)) (((betS A) B) P))))))`*)
let lemma__ray1 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(P : mat_Point)` 
   (DISCH `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
    (MP  
     (CONV_CONV_rule `((mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))) ==> mat_false) ==> ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
      (DISCH `mat_not (mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
       (MP  
        (CONV_CONV_rule `((mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))) ==> mat_false) ==> ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
         (SPEC `(mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
          (nNPP))
        ) (DISCH `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
           (MP  
            (DISCH `mat_false` 
             (MP  
              (DISCH `(((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> mat_false` 
               (MP  
                (DISCH `((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false` 
                 (MP  
                  (DISCH `((eq (B : mat_Point)) (P : mat_Point)) ==> mat_false` 
                   (MP  
                    (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> mat_false` 
                     (MP  
                      (SPEC `mat_false` (false__ind)) (ASSUME `mat_false`))
                    ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                       (MP  
                        (ASSUME `((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false`
                        ) (MP  
                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                            (SPEC `(eq (B : mat_Point)) (P : mat_Point)` 
                             (or__intror))
                           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                           )))))
                  ) (DISCH `(eq (B : mat_Point)) (P : mat_Point)` 
                     (MP  
                      (ASSUME `((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false`
                      ) (MP  
                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                          (SPEC `(eq (B : mat_Point)) (P : mat_Point)` 
                           (or__introl))
                         ) (ASSUME `(eq (B : mat_Point)) (P : mat_Point)`))))
                 )
                ) (DISCH `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                   (MP  
                    (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> mat_false` 
                     (ASSUME `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                     )
                    ) (MP  
                       (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                        (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                         (or__intror))
                       ) (ASSUME `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                       )))))
              ) (DISCH `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                 (MP  
                  (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> mat_false` 
                   (ASSUME `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                   )
                  ) (MP  
                     (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                      (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                       (or__introl))
                     ) (ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                     )))))
            ) (MP  
               (CONV_CONV_rule `(mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))) ==> mat_false` 
                (ASSUME `mat_not (mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))`
                )
               ) (ASSUME `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
               ))))))
     ) (DISCH `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
        (MP  
         (DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
          (MP  
           (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> mat_false` 
              (ASSUME `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
              )
             ) (MP  
                (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                 (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                  (or__intror))
                ) (MP  
                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                    (SPEC `(eq (B : mat_Point)) (P : mat_Point)` (or__intror)
                    )
                   ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                   ))))
           ) (MP  
              (CONV_CONV_rule `((((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `(P : mat_Point)` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(A : mat_Point)` (lemma__ray)))
                 ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                 )) (ASSUME `(neq (P : mat_Point)) (B : mat_Point)`))
              ) (DISCH `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                 (MP  
                  (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> mat_false` 
                   (ASSUME `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                   )
                  ) (MP  
                     (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                      (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                       (or__introl))
                     ) (ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                     ))))))
         ) (MP  
            (CONV_CONV_rule `(((eq (B : mat_Point)) (P : mat_Point)) ==> mat_false) ==> ((neq (P : mat_Point)) (B : mat_Point))` 
             (SPEC `(P : mat_Point)` 
              (SPEC `(B : mat_Point)` (lemma__inequalitysymmetric)))
            ) (MP  
               (DISCH `(((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> mat_false` 
                (MP  
                 (DISCH `((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false` 
                  (MP  
                   (DISCH `((eq (B : mat_Point)) (P : mat_Point)) ==> mat_false` 
                    (MP  
                     (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> mat_false` 
                      (ASSUME `((eq (B : mat_Point)) (P : mat_Point)) ==> mat_false`
                      )
                     ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                        (MP  
                         (ASSUME `((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false`
                         ) (MP  
                            (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                             (SPEC `(eq (B : mat_Point)) (P : mat_Point)` 
                              (or__intror))
                            ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                            )))))
                   ) (DISCH `(eq (B : mat_Point)) (P : mat_Point)` 
                      (MP  
                       (ASSUME `((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ==> mat_false`
                       ) (MP  
                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                           (SPEC `(eq (B : mat_Point)) (P : mat_Point)` 
                            (or__introl))
                          ) (ASSUME `(eq (B : mat_Point)) (P : mat_Point)`)))
                   ))
                 ) (DISCH `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                    (MP  
                     (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> mat_false` 
                      (ASSUME `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                      )
                     ) (MP  
                        (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                         (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                          (or__intror))
                        ) (ASSUME `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                        )))))
               ) (DISCH `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))) ==> mat_false` 
                    (ASSUME `mat_not ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                    )
                   ) (MP  
                      (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                       (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                        (or__introl))
                      ) (ASSUME `((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                      ))))))))))))
 ;;


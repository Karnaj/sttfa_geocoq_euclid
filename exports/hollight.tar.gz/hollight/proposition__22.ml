(*lemma__togethera :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! G : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((tG A) a) B) b) C) c) ==> (((((cong D) F) A) a) ==> (((((cong F) G) B) b) ==> ((((betS D) F) G) ==> (((((cong P) Q) C) c) ==> ((((lt P) Q) D) G))))))))))))))))`*)
let lemma__togethera =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(F : mat_Point)` 
     (GEN `(G : mat_Point)` 
      (GEN `(P : mat_Point)` 
       (GEN `(Q : mat_Point)` 
        (GEN `(a : mat_Point)` 
         (GEN `(b : mat_Point)` 
          (GEN `(c : mat_Point)` 
           (DISCH `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
            (DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
             (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
              (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
               (DISCH `(((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                (MP  
                 (DISCH `((((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> (((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) ==> (((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> (((((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))))))` 
                  (MP  
                   (MP  
                    (MP  
                     (MP  
                      (MP  
                       (ASSUME `((((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> (((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) ==> (((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> (((((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))))))`
                       ) (ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                       )
                      ) (ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                      )
                     ) (ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                     )
                    ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                    )
                   ) (ASSUME `(((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                   ))
                 ) (DISCH `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                    (DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                     (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                      (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                       (DISCH `(((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                        (MP  
                         (MP  
                          (SPEC `(((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                           (SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point)))` 
                            (SPEC `(((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                             (DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point)))` 
                              (ASSUME `(((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                              )))
                         ) (MP  
                            (MP  
                             (MP  
                              (MP  
                               (MP  
                                (SPEC `(c : mat_Point)` 
                                 (SPEC `(b : mat_Point)` 
                                  (SPEC `(a : mat_Point)` 
                                   (SPEC `(Q : mat_Point)` 
                                    (SPEC `(P : mat_Point)` 
                                     (SPEC `(G : mat_Point)` 
                                      (SPEC `(F : mat_Point)` 
                                       (SPEC `(D : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (lemma__together)))))))))))
                                ) (ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                )
                               ) (ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                               )
                              ) (ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                              )
                             ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                             )
                            ) (ASSUME `(((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                            ))))))))))))))))))))))))
 ;;

(*proposition__22 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! E : mat_Point. (! F : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((tG A) a) B) b) C) c) ==> (((((((tG A) a) C) c) B) b) ==> (((((((tG B) b) C) c) A) a) ==> (((neq F) E) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong F) X) B) b)) ((mat_and ((((cong F) Y) A) a)) ((mat_and ((((cong X) Y) C) c)) ((mat_and (((out F) E) X)) (((triangle F) X) Y))))))))))))))))))))`*)
let proposition__22 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(E : mat_Point)` 
    (GEN `(F : mat_Point)` 
     (GEN `(a : mat_Point)` 
      (GEN `(b : mat_Point)` 
       (GEN `(c : mat_Point)` 
        (DISCH `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
         (DISCH `(((((tG (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
          (DISCH `(((((tG (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
           (DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
              (DISCH `ex (\ P : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)))))` 
               (MP  
                (MP  
                 (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (x : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)))))) ==> (return : bool)))` 
                   (SPEC `\ P : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(P : mat_Point)` 
                    (DISCH `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                        (SPEC `(mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                         (SPEC `((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point)` 
                          (DISCH `(mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                              (SPEC `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                               (SPEC `(((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                (DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                 (MP  
                                  (DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                   (MP  
                                    (DISCH `(neq (a : mat_Point)) (P : mat_Point)` 
                                     (MP  
                                      (DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                       (MP  
                                        (DISCH `(neq (C : mat_Point)) (c : mat_Point)` 
                                         (MP  
                                          (DISCH `ex (\ G : mat_Point. ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (F : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (F : mat_Point)) (x : mat_Point)) (B : mat_Point)) (b : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))))) ==> (return : bool)))` 
                                               (SPEC `\ G : mat_Point. ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__ind))))
                                             ) (GEN `(G : mat_Point)` 
                                                (DISCH `(mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                    (SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                     (SPEC `((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                      (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(neq (F : mat_Point)) (G : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(neq (G : mat_Point)) (F : mat_Point)` 
                                                             (MP  
                                                              (DISCH `ex (\ H20 : mat_Point. ((mat_and (((betS (F : mat_Point)) (G : mat_Point)) (H20 : mat_Point))) ((((cong (G : mat_Point)) (H20 : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (C : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ H21 : mat_Point. ((mat_and (((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                                                                   (SPEC `\ H21 : mat_Point. ((mat_and (((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                   ))
                                                                 ) (GEN `(H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((((cong (F : mat_Point)) (x : mat_Point)) (A : mat_Point)) (a : mat_Point))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ L : mat_Circle. ((((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Circle. (((((cI (x : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> (return : bool))) ==> ((ex (\ L : mat_Circle. ((((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ L : mat_Circle. ((((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    PINST [(`:mat_Circle`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(L : mat_Circle)` 
                                                                    (
                                                                    DISCH `(((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ R : mat_Circle. ((((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Circle. (((((cI (x : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)) ==> (return : bool))) ==> ((ex (\ R : mat_Circle. ((((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Circle. ((((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point))` 
                                                                    (
                                                                    PINST [(`:mat_Circle`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Circle)` 
                                                                    (
                                                                    DISCH `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `(onCirc (H21 : mat_Point)) (R : mat_Circle)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (D : mat_Point)) (F : mat_Point)) (F : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (D : mat_Point)) (F : mat_Point)) (F : mat_Point)) (H21 : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (x : mat_Point)) (D : mat_Point)) (F : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `(outCirc (H21 : mat_Point)) (L : mat_Circle)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (G : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ N : mat_Point. ((mat_and (((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (C : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ N : mat_Point. ((mat_and (((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ N : mat_Point. ((mat_and (((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (N : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((((cong (M : mat_Point)) (x : mat_Point)) (C : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (x : mat_Point)) (F : mat_Point)) (G : mat_Point))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (F : mat_Point)) (J : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (G : mat_Point))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(inCirc (N : mat_Point)) (L : mat_Circle)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `(onCirc (N : mat_Point)) (R : mat_Circle)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ K : mat_Point. ((mat_and ((onCirc (K : mat_Point)) (L : mat_Circle))) ((onCirc (K : mat_Point)) (R : mat_Circle))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((onCirc (x : mat_Point)) (L : mat_Circle))) ((onCirc (x : mat_Point)) (R : mat_Circle))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and ((onCirc (K : mat_Point)) (L : mat_Circle))) ((onCirc (K : mat_Point)) (R : mat_Circle))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ K : mat_Point. ((mat_and ((onCirc (K : mat_Point)) (L : mat_Circle))) ((onCirc (K : mat_Point)) (R : mat_Circle)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((onCirc (K : mat_Point)) (L : mat_Circle))) ((onCirc (K : mat_Point)) (R : mat_Circle))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(onCirc (K : mat_Point)) (R : mat_Circle)` 
                                                                    (
                                                                    SPEC `(onCirc (K : mat_Point)) (L : mat_Circle)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(onCirc (K : mat_Point)) (L : mat_Circle)` 
                                                                    (
                                                                    DISCH `(onCirc (K : mat_Point)) (R : mat_Circle)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    DISCH `((triangle (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (x : mat_Point))) (((triangle (F : mat_Point)) (x : mat_Point)) (Y : mat_Point)))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (X : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((triangle (F : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) (((triangle (F : mat_Point)) (G : mat_Point)) (x : mat_Point)))))) ==> (ex (\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) (((triangle (F : mat_Point)) (G : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. ((mat_and ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (Y : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (Y : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) (((triangle (F : mat_Point)) (G : mat_Point)) (Y : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) (((triangle (F : mat_Point)) (G : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) (((triangle (F : mat_Point)) (G : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) (((triangle (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((triangle (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (F : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (G : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (G : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (x : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (S : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (S : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((lt (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((lt (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__trichotomy2
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((lt (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (S : mat_Point)) (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (S : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (S : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (S : mat_Point)) (A : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (S : mat_Point)) (A : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (S : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (S : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (S : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (S : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (S : mat_Point)) (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and ((((cong (S : mat_Point)) (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (G : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (S : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (a : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (S : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (S : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (K : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (K : mat_Point)) (a : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (K : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (K : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (K : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (K : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (K : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (K : mat_Point)) (a : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (K : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (K : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (K : mat_Point)) (a : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((tG (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (a : mat_Point)) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (K : mat_Point)) (b : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((lt (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((lt (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__trichotomy2
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (S : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (b : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ S : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (S : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((tG (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((tG (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (x : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (G : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (K : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (S : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((nCol (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__trichotomy2
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (G : mat_Point)) (A : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (S : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (A : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (K : mat_Point)) (G : mat_Point)) (S : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (S : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (S : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (G : mat_Point)) (S : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (K : mat_Point)) (G : mat_Point)) (S : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (S : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (K : mat_Point)) (S : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (K : mat_Point)) (S : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (S : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (K : mat_Point)) (G : mat_Point)) (S : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (K : mat_Point)) (G : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((((cong (G : mat_Point)) (K : mat_Point)) (S : mat_Point)) (a : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (a : mat_Point)) (S : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (a : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (S : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((lt (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (S : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (F : mat_Point)) (G : mat_Point))) ((mat_or ((eq (F : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_or (((betS (F : mat_Point)) (G : mat_Point)) (K : mat_Point))) (((betS (F : mat_Point)) (K : mat_Point)) (G : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Circle)` 
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__circle__center__radius
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (K : mat_Point)) (R : mat_Circle)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (K : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Circle)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__circle__center__radius
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (K : mat_Point)) (L : mat_Circle)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((onCirc (K : mat_Point)) (L : mat_Circle))) ((onCirc (K : mat_Point)) (R : mat_Circle))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ K : mat_Point. ((mat_and ((onCirc (K : mat_Point)) (L : mat_Circle))) ((onCirc (K : mat_Point)) (R : mat_Circle))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Circle)` 
                                                                    (
                                                                    SPEC `(L : mat_Circle)` 
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    postulate__circle__circle
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(inCirc (N : mat_Point)) (L : mat_Circle)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(outCirc (H21 : mat_Point)) (L : mat_Circle)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (N : mat_Point)) (R : mat_Circle)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (H21 : mat_Point)) (R : mat_Circle)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (x : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (x : mat_Point)) (Y : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (G : mat_Point)) (x : mat_Point))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (G : mat_Point)) (Y : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (G : mat_Point)) (Y : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (R : mat_Circle)) (x : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (x : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ==> (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H21 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H21 : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    cn__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Circle)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__ondiameter
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__subtractequals
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (J : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (J : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (J : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (N : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (N : mat_Point)) (J : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (J : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (J : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (J : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (Q : mat_Point)) ==> (((betS (F : mat_Point)) (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (G : mat_Point)) ==> ((((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point)) ==> (((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> (((neq (F : mat_Point)) (G : mat_Point)) ==> (((neq (G : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point)) ==> (((((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> (((neq (G : mat_Point)) (H21 : mat_Point)) ==> (((((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)) ==> (((((cong (G : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (G : mat_Point)) ==> (((((cong (D : mat_Point)) (G : mat_Point)) (G : mat_Point)) (D : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (D : mat_Point)) ==> ((((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point)) ==> (((((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (D : mat_Point)) (N : mat_Point)) (G : mat_Point)) ==> (((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point)) ==> (((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> ((((out (F : mat_Point)) (G : mat_Point)) (J : mat_Point)) ==> ((((out (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) ==> (((eq (G : mat_Point)) (Q : mat_Point)) ==> (((betS (F : mat_Point)) (G : mat_Point)) (J : mat_Point)))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (F : mat_Point)) (E : mat_Point)) (Q : mat_Point)) ==> (((((cong (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (Q : mat_Point)) ==> (((neq (F : mat_Point)) (Q : mat_Point)) ==> (((neq (Q : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (Q : mat_Point)) (H21 : mat_Point)) ==> (((((cong (Q : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (Q : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (Q : mat_Point)) ==> (((neq (Q : mat_Point)) (H21 : mat_Point)) ==> (((((cI (R : mat_Circle)) (Q : mat_Point)) (Q : mat_Point)) (H21 : mat_Point)) ==> (((((cong (Q : mat_Point)) (H21 : mat_Point)) (Q : mat_Point)) (H21 : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (Q : mat_Point)) ==> (((((cong (D : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (D : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (Q : mat_Point)) (D : mat_Point)) ==> ((((betS (Q : mat_Point)) (N : mat_Point)) (D : mat_Point)) ==> (((((cong (Q : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (D : mat_Point)) (N : mat_Point)) (Q : mat_Point)) ==> (((((lt (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (J : mat_Point)) ==> (((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (Q : mat_Point)) ==> ((((out (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)) ==> ((((out (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)) ==> (((eq (Q : mat_Point)) (Q : mat_Point)) ==> (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))))))))))))))))))))))))) ==> (! y : mat_Point. (((eq (Q : mat_Point)) (y : mat_Point)) ==> ((((out (F : mat_Point)) (E : mat_Point)) (y : mat_Point)) ==> (((((cong (F : mat_Point)) (y : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (y : mat_Point)) ==> (((neq (F : mat_Point)) (y : mat_Point)) ==> (((neq (y : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (y : mat_Point)) (H21 : mat_Point)) ==> (((((cong (y : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (y : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (y : mat_Point)) ==> (((neq (y : mat_Point)) (H21 : mat_Point)) ==> (((((cI (R : mat_Circle)) (y : mat_Point)) (y : mat_Point)) (H21 : mat_Point)) ==> (((((cong (y : mat_Point)) (H21 : mat_Point)) (y : mat_Point)) (H21 : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (y : mat_Point)) ==> (((((cong (D : mat_Point)) (y : mat_Point)) (y : mat_Point)) (D : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (y : mat_Point)) (D : mat_Point)) ==> ((((betS (y : mat_Point)) (N : mat_Point)) (D : mat_Point)) ==> (((((cong (y : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (D : mat_Point)) (N : mat_Point)) (y : mat_Point)) ==> (((((lt (F : mat_Point)) (y : mat_Point)) (F : mat_Point)) (J : mat_Point)) ==> (((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (y : mat_Point)) ==> ((((out (F : mat_Point)) (y : mat_Point)) (J : mat_Point)) ==> ((((out (F : mat_Point)) (J : mat_Point)) (y : mat_Point)) ==> (((eq (y : mat_Point)) (Q : mat_Point)) ==> (((betS (F : mat_Point)) (y : mat_Point)) (J : mat_Point)))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ G0 : mat_Point. ((((out (F : mat_Point)) (E : mat_Point)) (G0 : mat_Point)) ==> (((((cong (F : mat_Point)) (G0 : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (G0 : mat_Point)) ==> (((neq (F : mat_Point)) (G0 : mat_Point)) ==> (((neq (G0 : mat_Point)) (F : mat_Point)) ==> ((((betS (F : mat_Point)) (G0 : mat_Point)) (H21 : mat_Point)) ==> (((((cong (G0 : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (G0 : mat_Point)) (F : mat_Point)) (D : mat_Point)) ==> ((((betS (D : mat_Point)) (F : mat_Point)) (G0 : mat_Point)) ==> (((neq (G0 : mat_Point)) (H21 : mat_Point)) ==> (((((cI (R : mat_Circle)) (G0 : mat_Point)) (G0 : mat_Point)) (H21 : mat_Point)) ==> (((((cong (G0 : mat_Point)) (H21 : mat_Point)) (G0 : mat_Point)) (H21 : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (G0 : mat_Point)) ==> (((((cong (D : mat_Point)) (G0 : mat_Point)) (G0 : mat_Point)) (D : mat_Point)) ==> (((((lt (C : mat_Point)) (c : mat_Point)) (G0 : mat_Point)) (D : mat_Point)) ==> ((((betS (G0 : mat_Point)) (N : mat_Point)) (D : mat_Point)) ==> (((((cong (G0 : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (D : mat_Point)) (N : mat_Point)) (G0 : mat_Point)) ==> (((((lt (F : mat_Point)) (G0 : mat_Point)) (F : mat_Point)) (J : mat_Point)) ==> (((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G0 : mat_Point)) ==> ((((out (F : mat_Point)) (G0 : mat_Point)) (J : mat_Point)) ==> ((((out (F : mat_Point)) (J : mat_Point)) (G0 : mat_Point)) ==> (((eq (G0 : mat_Point)) (Q : mat_Point)) ==> (((betS (F : mat_Point)) (G0 : mat_Point)) (J : mat_Point)))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (F : mat_Point)) (E : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (Q : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cI (R : mat_Circle)) (Q : mat_Point)) (Q : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (H21 : mat_Point)) (Q : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (Q : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (N : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (N : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (G : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (F : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (F : mat_Point)) (J : mat_Point))) (((betS (x : mat_Point)) (F : mat_Point)) (G : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (F : mat_Point)) (J : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (G : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (F : mat_Point)) (J : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (J : mat_Point))) (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (J : mat_Point))) ((mat_and ((neq (F : mat_Point)) (Q : mat_Point))) ((neq (F : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (Q : mat_Point))) ((neq (F : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (Q : mat_Point))) ((neq (F : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (Q : mat_Point))) ((neq (F : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (J : mat_Point))) ((mat_and ((neq (F : mat_Point)) (Q : mat_Point))) ((neq (F : mat_Point)) (J : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))))) ==> (ex (\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ Q : mat_Point. ((mat_and (((betS (F : mat_Point)) (Q : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (Q : mat_Point)) (F : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (X : mat_Point)) (J : mat_Point))) ((((cong (F : mat_Point)) (X : mat_Point)) (F : mat_Point)) (G : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((lt (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (B : mat_Point)) (b : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__together
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (J : mat_Point))) ((((cong (M : mat_Point)) (J : mat_Point)) (C : mat_Point)) (c : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (c : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (c : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (c : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (N : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (N : mat_Point)) (G : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (N : mat_Point)) (G : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (N : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (c : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (N : mat_Point)) (G : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (c : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ N : mat_Point. ((mat_and (((betS (G : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (N : mat_Point)) (C : mat_Point)) (c : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (G : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__togethera
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (x : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (x : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (F : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (x : mat_Point)) (W : mat_Point)))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (x : mat_Point)))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (W : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ W : mat_Point. ((mat_and ((((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (W : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    cn__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (H21 : mat_Point))) ((((cong (F : mat_Point)) (M : mat_Point)) (D : mat_Point)) (F : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (D : mat_Point)) (F : mat_Point)) (F : mat_Point)) (H21 : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! F0 : mat_Point. (! G0 : mat_Point. (! P0 : mat_Point. (! Q : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((((tG (A0 : mat_Point)) (a0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)) ==> (((((cong (D0 : mat_Point)) (F0 : mat_Point)) (A0 : mat_Point)) (a0 : mat_Point)) ==> (((((cong (F0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)) ==> ((((betS (D0 : mat_Point)) (F0 : mat_Point)) (G0 : mat_Point)) ==> (((((cong (P0 : mat_Point)) (Q : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)) ==> ((((lt (P0 : mat_Point)) (Q : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! F0 : mat_Point. (! G0 : mat_Point. (! P0 : mat_Point. (! Q : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((((tG (A0 : mat_Point)) (a0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)) ==> (((((cong (D0 : mat_Point)) (F0 : mat_Point)) (A0 : mat_Point)) (a0 : mat_Point)) ==> (((((cong (F0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)) ==> ((((betS (D0 : mat_Point)) (F0 : mat_Point)) (G0 : mat_Point)) ==> (((((cong (P0 : mat_Point)) (Q : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)) ==> ((((lt (P0 : mat_Point)) (Q : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)))))))))))))))))`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((((tG (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(F0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(P0 : mat_Point)` 
                                                                    (
                                                                    GEN `(Q : mat_Point)` 
                                                                    (
                                                                    GEN `(a0 : mat_Point)` 
                                                                    (
                                                                    GEN `(b0 : mat_Point)` 
                                                                    (
                                                                    GEN `(c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((tG (A0 : mat_Point)) (a0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D0 : mat_Point)) (F0 : mat_Point)) (A0 : mat_Point)) (a0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D0 : mat_Point)) (F0 : mat_Point)) (G0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P0 : mat_Point)) (Q : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (P0 : mat_Point)) (Q : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A0 : mat_Point)) (a0 : mat_Point))) ((mat_and ((neq (B0 : mat_Point)) (b0 : mat_Point))) ((neq (C0 : mat_Point)) (c0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((lt (P0 : mat_Point)) (Q : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((lt (P0 : mat_Point)) (Q : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A0 : mat_Point)) (a0 : mat_Point))) ((mat_and ((neq (B0 : mat_Point)) (b0 : mat_Point))) ((neq (C0 : mat_Point)) (c0 : mat_Point)))` 
                                                                    (
                                                                    ASSUME `(((lt (P0 : mat_Point)) (Q : mat_Point)) (D0 : mat_Point)) (G0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(b0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(a0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(F0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    lemma__together
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((((tG (A0 : mat_Point)) (a0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D0 : mat_Point)) (F0 : mat_Point)) (A0 : mat_Point)) (a0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (b0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D0 : mat_Point)) (F0 : mat_Point)) (G0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P0 : mat_Point)) (Q : mat_Point)) (C0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (x : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (x : mat_Point)) (Y : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (x : mat_Point))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (Y : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (Y : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (R : mat_Circle)) (x : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (x : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ==> (ex (\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. ((mat_and ((((cI (R : mat_Circle)) (U : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (U : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (H21 : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Circle. ((((cI (R : mat_Circle)) (G : mat_Point)) (G : mat_Point)) (H21 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    postulate__Euclid3
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (H21 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `ex (\ L : mat_Circle. ((((cI (L : mat_Circle)) (F : mat_Point)) (F : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    postulate__Euclid3
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H21 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((neq (F : mat_Point)) (H21 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((neq (F : mat_Point)) (H21 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((neq (F : mat_Point)) (H21 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (H21 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (H21 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((neq (F : mat_Point)) (H21 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H21 : mat_Point))) ((mat_and ((neq (F : mat_Point)) (G : mat_Point))) ((neq (F : mat_Point)) (H21 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H21 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (F : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (F : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (F : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (F : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (F : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (D : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (a : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (a : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (D : mat_Point)) (F : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (a : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (F : mat_Point)) (D : mat_Point)) (A : mat_Point)) (a : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (G : mat_Point)) (H21 : mat_Point))) ((((cong (G : mat_Point)) (H21 : mat_Point)) (C : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `ex (\ H20 : mat_Point. ((mat_and (((betS (F : mat_Point)) (G : mat_Point)) (H20 : mat_Point))) ((((cong (G : mat_Point)) (H20 : mat_Point)) (C : mat_Point)) (c : mat_Point))))`
                                                                ))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(c : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(neq (F : mat_Point)) (G : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(neq (C : mat_Point)) (c : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (SPEC `(G : mat_Point)` 
                                                                (SPEC `(F : mat_Point)` 
                                                                 (lemma__inequalitysymmetric
                                                                 ))
                                                               ) (ASSUME `(neq (F : mat_Point)) (G : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(G : mat_Point)` 
                                                               (SPEC `(F : mat_Point)` 
                                                                (SPEC `(b : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (axiom__nocollapse
                                                                  ))))
                                                              ) (ASSUME `(neq (B : mat_Point)) (b : mat_Point)`
                                                              )
                                                             ) (ASSUME `(((cong (B : mat_Point)) (b : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (SPEC `(b : mat_Point)` 
                                                            (SPEC `(G : mat_Point)` 
                                                             (SPEC `(F : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (lemma__congruencesymmetric
                                                               ))))
                                                           ) (ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                           )))))
                                                  ) (ASSUME `(mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))`
                                                  ))))
                                            ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((out (F : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point))))`
                                            ))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(b : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(E : mat_Point)` 
                                                 (SPEC `(F : mat_Point)` 
                                                  (lemma__layoff))))
                                              ) (ASSUME `(neq (F : mat_Point)) (E : mat_Point)`
                                              )
                                             ) (ASSUME `(neq (B : mat_Point)) (b : mat_Point)`
                                             )))
                                        ) (MP  
                                           (DISCH `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (C : mat_Point)) (c : mat_Point)` 
                                               (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                                (SPEC `(neq (C : mat_Point)) (c : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (C : mat_Point)) (c : mat_Point)` 
                                                 (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                                  (ASSUME `(neq (C : mat_Point)) (c : mat_Point)`
                                                  )))
                                             ) (ASSUME `(mat_and ((neq (C : mat_Point)) (c : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))`
                                             ))
                                           ) (MP  
                                              (SPEC `(P : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(c : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (lemma__lessthannotequal)))
                                               )
                                              ) (ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (MP  
                                          (SPEC `(b : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(P : mat_Point)` 
                                             (SPEC `(a : mat_Point)` 
                                              (axiom__nocollapse))))
                                          ) (ASSUME `(neq (a : mat_Point)) (P : mat_Point)`
                                          )
                                         ) (ASSUME `(((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                         )))
                                    ) (MP  
                                       (DISCH `(mat_and ((neq (a : mat_Point)) (P : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (a : mat_Point)) (P : mat_Point)` 
                                           (SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))` 
                                            (SPEC `(neq (a : mat_Point)) (P : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (a : mat_Point)) (P : mat_Point)` 
                                             (DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (a : mat_Point)) (P : mat_Point)` 
                                                 (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                                  (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                   (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                                    (ASSUME `(neq (a : mat_Point)) (P : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (a : mat_Point)) (P : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point)))`
                                         ))
                                       ) (MP  
                                          (SPEC `(P : mat_Point)` 
                                           (SPEC `(a : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (lemma__betweennotequal)))
                                          ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point)`
                                          ))))
                                  ) (MP  
                                     (DISCH `(mat_and ((neq (a : mat_Point)) (P : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                         (SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))` 
                                          (SPEC `(neq (a : mat_Point)) (P : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (a : mat_Point)) (P : mat_Point)` 
                                           (DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                               (SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                                (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                 (DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                                  (ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                  )))
                                             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (a : mat_Point)) (P : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (P : mat_Point)))`
                                       ))
                                     ) (MP  
                                        (SPEC `(P : mat_Point)` 
                                         (SPEC `(a : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (lemma__betweennotequal)))
                                        ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point)`
                                        ))))))
                            ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                            ))))
                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                      ))))
                ) (ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (P : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (P : mat_Point)))))`
                )))
             ) (ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)`
             )))))))))))))
 ;;


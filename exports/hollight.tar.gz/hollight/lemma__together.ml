(*lemma__together :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! G : mat_Point. (! P : mat_Point. (! Q : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((tG A) a) B) b) C) c) ==> (((((cong D) F) A) a) ==> (((((cong F) G) B) b) ==> ((((betS D) F) G) ==> (((((cong P) Q) C) c) ==> ((mat_and ((((lt P) Q) D) G)) ((mat_and ((neq A) a)) ((mat_and ((neq B) b)) ((neq C) c)))))))))))))))))))`*)
let lemma__together =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(F : mat_Point)` 
     (GEN `(G : mat_Point)` 
      (GEN `(P : mat_Point)` 
       (GEN `(Q : mat_Point)` 
        (GEN `(a : mat_Point)` 
         (GEN `(b : mat_Point)` 
          (GEN `(c : mat_Point)` 
           (DISCH `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
            (DISCH `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
             (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
              (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
               (DISCH `(((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `((((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((mat_and ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point)))))` 
                  (DISCH `ex (\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)))))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_and ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point))))` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (x : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)))))) ==> (return : bool)))` 
                       (SPEC `\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(R : mat_Point)` 
                        (DISCH `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point))))` 
                            (SPEC `(mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point))` 
                             (SPEC `((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                              (DISCH `(mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(mat_and ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point))))` 
                                  (SPEC `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                   (SPEC `(((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                    (DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                     (MP  
                                      (DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                         (MP  
                                          (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                           (MP  
                                            (DISCH `(((cong (D : mat_Point)) (G : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                             (MP  
                                              (DISCH `(((cong (A : mat_Point)) (R : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (C : mat_Point)) (c : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((lt (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(neq (a : mat_Point)) (R : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((mat_and ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point)))))` 
                                                             (DISCH `ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(mat_and ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point))))` 
                                                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                                                                  (SPEC `\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                  ))
                                                                ) (GEN `(S : mat_Point)` 
                                                                   (DISCH `(mat_and (((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((lt (P : mat_Point)) (Q : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (b : mat_Point))) ((neq (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (S : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (S : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (S : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (S : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (S : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (S : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (S : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (S : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (S : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (S : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(S : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `ex (\ S : mat_Point. ((mat_and (((betS (A : mat_Point)) (S : mat_Point)) (R : mat_Point))) ((((cong (A : mat_Point)) (S : mat_Point)) (C : mat_Point)) (c : mat_Point))))`
                                                               )))
                                                            ) (ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                            ))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(b : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(R : mat_Point)` 
                                                                 (SPEC `(a : mat_Point)` 
                                                                  (axiom__nocollapse
                                                                  ))))
                                                              ) (ASSUME `(neq (a : mat_Point)) (R : mat_Point)`
                                                              )
                                                             ) (ASSUME `(((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (DISCH `(mat_and ((neq (a : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (a : mat_Point)) (R : mat_Point)` 
                                                               (SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                (SPEC `(neq (a : mat_Point)) (R : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (a : mat_Point)) (R : mat_Point)` 
                                                                 (DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (a : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(R : mat_Point)` 
                                                               (SPEC `(a : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (lemma__betweennotequal
                                                                 )))
                                                              ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (DISCH `(mat_and ((neq (a : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                             (SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                              (SPEC `(neq (a : mat_Point)) (R : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (a : mat_Point)) (R : mat_Point)` 
                                                               (DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                   (SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                  (DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                                                   (ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((neq (a : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (R : mat_Point)))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(R : mat_Point)` 
                                                             (SPEC `(a : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (lemma__betweennotequal
                                                               )))
                                                            ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(G : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(R : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (SPEC `(Q : mat_Point)` 
                                                             (SPEC `(P : mat_Point)` 
                                                              (lemma__lessthancongruence
                                                              ))))))
                                                        ) (ASSUME `(((lt (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (A : mat_Point)) (R : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(Q : mat_Point)` 
                                                       (SPEC `(P : mat_Point)` 
                                                        (SPEC `(R : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(c : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (lemma__lessthancongruence2
                                                            ))))))
                                                      ) (ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (C : mat_Point)) (c : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (SPEC `(c : mat_Point)` 
                                                    (SPEC `(Q : mat_Point)` 
                                                     (SPEC `(P : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (lemma__congruencesymmetric
                                                       ))))
                                                   ) (ASSUME `(((cong (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (SPEC `(R : mat_Point)` 
                                                  (SPEC `(G : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__congruencesymmetric
                                                     ))))
                                                 ) (ASSUME `(((cong (D : mat_Point)) (G : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (MP  
                                                (MP  
                                                 (MP  
                                                  (SPEC `(R : mat_Point)` 
                                                   (SPEC `(a : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (SPEC `(G : mat_Point)` 
                                                      (SPEC `(F : mat_Point)` 
                                                       (SPEC `(D : mat_Point)` 
                                                        (cn__sumofparts))))))
                                                  ) (ASSUME `(((cong (D : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                 )
                                                ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                )
                                               ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                               )))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(R : mat_Point)` 
                                               (SPEC `(a : mat_Point)` 
                                                (SPEC `(b : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(G : mat_Point)` 
                                                   (SPEC `(F : mat_Point)` 
                                                    (lemma__congruencetransitive
                                                    ))))))
                                              ) (ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                              )
                                             ) (ASSUME `(((cong (B : mat_Point)) (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                             )))
                                        ) (MP  
                                           (SPEC `(b : mat_Point)` 
                                            (SPEC `(R : mat_Point)` 
                                             (SPEC `(a : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (lemma__congruencesymmetric)))
                                            )
                                           ) (ASSUME `(((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                           )))
                                      ) (SPEC `(a : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (cn__congruencereflexive))))))
                                ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)))`
                          ))))
                    ) (ASSUME `ex (\ R : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (R : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (R : mat_Point)))))`
                    )))
                 ) (ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                 )))))))))))))))))
 ;;


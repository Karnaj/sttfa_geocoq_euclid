(*lemma__lessthancongruence :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((lt A) B) C) D) ==> (((((cong C) D) E) F) ==> ((((lt A) B) E) F))))))))`*)
let lemma__lessthancongruence =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
        (MP  
         (CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
          (DISCH `ex (\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
           (MP  
            (MP  
             (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
               (SPEC `\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(G : mat_Point)` 
                (DISCH `(mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                    (SPEC `(((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                     (SPEC `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                      (DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                         (MP  
                          (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `(((eq (F : mat_Point)) (E : mat_Point)) ==> mat_false) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                             (DISCH `mat_not ((eq (F : mat_Point)) (E : mat_Point))` 
                              (MP  
                               (DISCH `ex (\ P : mat_Point. ((mat_and (((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (F : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                    (SPEC `\ P : mat_Point. ((mat_and (((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(P : mat_Point)` 
                                     (DISCH `(mat_and (((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                         (SPEC `(((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                          (SPEC `((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                           (DISCH `(((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                            (MP  
                                             (DISCH `((betS (P : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                              (MP  
                                               (DISCH `(neq (P : mat_Point)) (E : mat_Point)` 
                                                (MP  
                                                 (DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (MP  
                                                     (DISCH `ex (\ H16 : mat_Point. ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (H16 : mat_Point))) ((((cong (E : mat_Point)) (H16 : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ H17 : mat_Point. ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point))) ((((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                          (SPEC `\ H17 : mat_Point. ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point))) ((((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__ind))))
                                                        ) (GEN `(H17 : mat_Point)` 
                                                           (DISCH `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point))) ((((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                               (SPEC `(((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point)` 
                                                                 (DISCH `(((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(((eq (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ Q : mat_Point. ((mat_and (((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (E : mat_Point)) (P : mat_Point))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Q : mat_Point. ((mat_and (((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (C : mat_Point)) (E : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (H17 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H17 : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H17 : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennesspreserved
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H17 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H17 : mat_Point)) (F : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H17 : mat_Point)) (F : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H17 : mat_Point)) (F : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H17 : mat_Point)) (F : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (G : mat_Point)) (D : mat_Point)) (H17 : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (H17 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H17 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (D : mat_Point)) (P : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H17 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (C : mat_Point)) (P : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (C : mat_Point)) (E : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (P : mat_Point)) (P : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Q : mat_Point. ((mat_and (((betS (D : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (P : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (D : mat_Point)) (C : mat_Point))) ==> (((neq (E : mat_Point)) (P : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (D : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (E : mat_Point)) (P : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (D : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H17 : mat_Point))) ((mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (H17 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (H17 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (H17 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (H17 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H17 : mat_Point))) ((mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (H17 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   DISCH `(eq (D : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennessidentity
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (C : mat_Point)) ==> (((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)) ==> (((neq (C : mat_Point)) (D : mat_Point)) ==> (((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (C : mat_Point)) ==> (((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> (((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((betS (C : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ D0 : mat_Point. (((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) ==> (((((cong (C : mat_Point)) (D0 : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((betS (C : mat_Point)) (G : mat_Point)) (D0 : mat_Point)) ==> (((neq (C : mat_Point)) (D0 : mat_Point)) ==> (((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                             ) (ASSUME `(mat_and (((betS (P : mat_Point)) (E : mat_Point)) (H17 : mat_Point))) ((((cong (E : mat_Point)) (H17 : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `ex (\ H16 : mat_Point. ((mat_and (((betS (P : mat_Point)) (E : mat_Point)) (H16 : mat_Point))) ((((cong (E : mat_Point)) (H16 : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                       ))
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (SPEC `(P : mat_Point)` 
                                                             (lemma__extension
                                                             ))))
                                                         ) (ASSUME `(neq (P : mat_Point)) (E : mat_Point)`
                                                         )
                                                        ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(G : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (axiom__nocollapse
                                                           ))))
                                                       ) (ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                        (SPEC `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                         (SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                              (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                 (ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                                 )))
                                                            ) (ASSUME `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(D : mat_Point)` 
                                                        (SPEC `(G : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (lemma__betweennotequal
                                                          )))
                                                       ) (ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                       ))))
                                               ) (MP  
                                                  (DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (F : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (P : mat_Point)) (E : mat_Point)` 
                                                      (SPEC `(mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (F : mat_Point))` 
                                                       (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                        (DISCH `(mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (F : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(neq (P : mat_Point)) (E : mat_Point)` 
                                                            (SPEC `(neq (P : mat_Point)) (F : mat_Point)` 
                                                             (SPEC `(neq (P : mat_Point)) (E : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(neq (P : mat_Point)) (E : mat_Point)` 
                                                              (DISCH `(neq (P : mat_Point)) (F : mat_Point)` 
                                                               (ASSUME `(neq (P : mat_Point)) (E : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (F : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (P : mat_Point)) (E : mat_Point))) ((neq (P : mat_Point)) (F : mat_Point)))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(F : mat_Point)` 
                                                      (SPEC `(E : mat_Point)` 
                                                       (SPEC `(P : mat_Point)` 
                                                        (lemma__betweennotequal
                                                        )))
                                                     ) (ASSUME `((betS (P : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                     ))))
                                             ) (MP  
                                                (SPEC `(P : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(F : mat_Point)` 
                                                   (axiom__betweennesssymmetry
                                                   )))
                                                ) (ASSUME `((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point)`
                                                )))))
                                       ) (ASSUME `(mat_and (((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point))`
                                       ))))
                                 ) (ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (F : mat_Point)) (E : mat_Point)) (P : mat_Point))) ((((cong (E : mat_Point)) (P : mat_Point)) (F : mat_Point)) (E : mat_Point))))`
                                 ))
                               ) (MP  
                                  (CONV_CONV_rule `(mat_not ((eq (F : mat_Point)) (E : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (F : mat_Point)) (E : mat_Point)))))` 
                                   (MP  
                                    (CONV_CONV_rule `(mat_not ((eq (F : mat_Point)) (E : mat_Point))) ==> (((neq (F : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (F : mat_Point)) (E : mat_Point)) (X : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (F : mat_Point)) (E : mat_Point))))))` 
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(F : mat_Point)` 
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(F : mat_Point)` 
                                         (lemma__extension)))))
                                    ) (ASSUME `mat_not ((eq (F : mat_Point)) (E : mat_Point))`
                                    ))
                                  ) (ASSUME `mat_not ((eq (F : mat_Point)) (E : mat_Point))`
                                  ))))
                            ) (DISCH `(eq (F : mat_Point)) (E : mat_Point)` 
                               (MP  
                                (DISCH `(eq (E : mat_Point)) (F : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((eq (E : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                   (ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                   )
                                  ) (ASSUME `(eq (E : mat_Point)) (F : mat_Point)`
                                  ))
                                ) (MP  
                                   (SPEC `(F : mat_Point)` 
                                    (SPEC `(E : mat_Point)` 
                                     (lemma__equalitysymmetric))
                                   ) (ASSUME `(eq (F : mat_Point)) (E : mat_Point)`
                                   )))))
                          ) (MP  
                             (MP  
                              (SPEC `(F : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(C : mat_Point)` (axiom__nocollapse))
                                ))
                              ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                              )
                             ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                             )))
                        ) (MP  
                           (DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                               (SPEC `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                (SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                 (DISCH `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                     (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                       (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                        (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                        )))
                                   ) (ASSUME `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                             ))
                           ) (MP  
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(G : mat_Point)` 
                                (SPEC `(C : mat_Point)` 
                                 (lemma__betweennotequal)))
                              ) (ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                              ))))))
                  ) (ASSUME `(mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                  ))))
            ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
            )))
         ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))))
 ;;


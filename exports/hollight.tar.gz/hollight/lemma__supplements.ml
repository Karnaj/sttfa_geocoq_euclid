(*lemma__supplements :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! F : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (! f : mat_Point. (((((((congA A) B) C) a) b) c) ==> ((((((supp A) B) C) D) F) ==> ((((((supp a) b) c) d) f) ==> ((((((congA D) B) F) d) b) f)))))))))))))`*)
let lemma__supplements =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(F : mat_Point)` 
     (GEN `(a : mat_Point)` 
      (GEN `(b : mat_Point)` 
       (GEN `(c : mat_Point)` 
        (GEN `(d : mat_Point)` 
         (GEN `(f : mat_Point)` 
          (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
           (DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
            (DISCH `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)` 
             (MP  
              (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
               (MP  
                (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (MP  
                  (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                   (MP  
                    (DISCH `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                     (MP  
                      (CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                       (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                        (MP  
                         (MP  
                          (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                            (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                          ) (GEN `(U : mat_Point)` 
                             (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                              (MP  
                               (MP  
                                (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                                  (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))
                                  ))
                                ) (GEN `(V : mat_Point)` 
                                   (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                                        (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                          (ex__ind))))
                                      ) (GEN `(u : mat_Point)` 
                                         (DISCH `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                              (SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__ind))))
                                            ) (GEN `(v : mat_Point)` 
                                               (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                   (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                    (SPEC `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                     (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                         (SPEC `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                          (SPEC `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                           (DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                               (SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                (SPEC `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                 (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (U : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (U : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(W : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ w : mat_Point. ((mat_and (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (u : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (U : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ w : mat_Point. ((mat_and (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ w : mat_Point. ((mat_and (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(w : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (F : mat_Point))))) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (F : mat_Point))))) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) ((mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point))))) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point))))) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point))))) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (U : mat_Point)) (B : mat_Point))) ((mat_or ((eq (U : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (W : mat_Point))) ((mat_or (((betS (B : mat_Point)) (U : mat_Point)) (W : mat_Point))) ((mat_or (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (U : mat_Point)) (W : mat_Point)) (B : mat_Point))))))) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> mat_false) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))))) ==> ((((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (D : mat_Point)) (B : mat_Point)) (F : mat_Point)) (d : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (x : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))) ==> (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (x : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))) ==> (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (x : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))) ==> (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (v0 : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point))) ((mat_and (((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point))) ((mat_and (((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (d : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (W : mat_Point)) (v : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (u : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (u : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (U : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (W : mat_Point))) ((mat_or (((betS (B : mat_Point)) (U : mat_Point)) (W : mat_Point))) ((mat_or (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (U : mat_Point)) (W : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (W : mat_Point))) ((mat_or (((betS (B : mat_Point)) (U : mat_Point)) (W : mat_Point))) ((mat_or (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (U : mat_Point)) (W : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (U : mat_Point)) (W : mat_Point))) ((mat_or (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (U : mat_Point)) (W : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (U : mat_Point)) (W : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (U : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (W : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (x : mat_Point)) (b : mat_Point)) (f : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (u : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (u : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (x : mat_Point)) (b : mat_Point)) (f : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (u : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (u : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (u : mat_Point)) (b : mat_Point))) ((neq (u : mat_Point)) (f : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (f : mat_Point)) (w : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (f : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (f : mat_Point)) (w : mat_Point)) ==> ((((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> ((((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)) ==> (((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (w : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)) ==> ((((out (b : mat_Point)) (w : mat_Point)) (w : mat_Point)) ==> (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (w : mat_Point)) ==> ((((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (x : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> ((((out (b : mat_Point)) (x : mat_Point)) (w : mat_Point)) ==> (((betS (u : mat_Point)) (b : mat_Point)) (x : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ f0 : mat_Point. ((((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f0 : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (f0 : mat_Point)) ==> ((((out (b : mat_Point)) (f0 : mat_Point)) (w : mat_Point)) ==> (((betS (u : mat_Point)) (b : mat_Point)) (f0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (w : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (f : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (b : mat_Point)) (w : mat_Point)) (f : mat_Point))) ((mat_or ((eq (f : mat_Point)) (w : mat_Point))) (((betS (b : mat_Point)) (f : mat_Point)) (w : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (f : mat_Point)) (w : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (x : mat_Point)) (b : mat_Point)) (f : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (b : mat_Point)) (w : mat_Point))) (((betS (X : mat_Point)) (b : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) ((mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) ((mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (u : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (u : mat_Point)) ==> (((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> ((((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (u : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (u : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> ((((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> ((((out (b : mat_Point)) (u : mat_Point)) (u : mat_Point)) ==> (((neq (u : mat_Point)) (b : mat_Point)) ==> (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> (((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> ((((betS (x : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> ((((out (b : mat_Point)) (x : mat_Point)) (u : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> (((betS (x : mat_Point)) (b : mat_Point)) (w : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ a0 : mat_Point. (((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (a0 : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> ((((betS (a0 : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> ((((out (b : mat_Point)) (a0 : mat_Point)) (u : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> (((betS (a0 : mat_Point)) (b : mat_Point)) (w : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (u : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((((supp (u : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (u : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (u : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (u : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) ((mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) ((mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (b : mat_Point)) (u : mat_Point)) (a : mat_Point))) ((mat_or ((eq (a : mat_Point)) (u : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (F : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (U : mat_Point)) (B : mat_Point))) ((neq (U : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (U : mat_Point)) (B : mat_Point))) ((neq (U : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (U : mat_Point)) (B : mat_Point))) ((neq (U : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (U : mat_Point)) (B : mat_Point))) ((neq (U : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (U : mat_Point)) (B : mat_Point))) ((neq (U : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (W : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (F : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (F : mat_Point)) (W : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point)) ==> (((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (W : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)) ==> ((((out (B : mat_Point)) (W : mat_Point)) (W : mat_Point)) ==> (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (W : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (W : mat_Point)) ==> (((betS (U : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ F0 : mat_Point. ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F0 : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F0 : mat_Point)) ==> ((((out (B : mat_Point)) (F0 : mat_Point)) (W : mat_Point)) ==> (((betS (U : mat_Point)) (B : mat_Point)) (F0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (W : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (W : mat_Point)) (F : mat_Point))) ((mat_or ((eq (F : mat_Point)) (W : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (W : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (F : mat_Point)) (W : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (x : mat_Point)) (B : mat_Point)) (F : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (B : mat_Point)) (W : mat_Point))) (((betS (X : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (U : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (U : mat_Point)) ==> (((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (U : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (U : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((out (B : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (U : mat_Point)) (B : mat_Point)) ==> (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((((congA (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((betS (x : mat_Point)) (B : mat_Point)) (W : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. (((((((congA (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((supp (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> ((((betS (A0 : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((out (B : mat_Point)) (A0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A0 : mat_Point)) (B : mat_Point)) ==> (((betS (A0 : mat_Point)) (B : mat_Point)) (W : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((((congA (U : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((((supp (U : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (W : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((((cong (B : mat_Point)) (U : mat_Point)) (u : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((((cong (B : mat_Point)) (U : mat_Point)) (u : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((((cong (B : mat_Point)) (U : mat_Point)) (u : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (U : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (U : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((((cong (B : mat_Point)) (U : mat_Point)) (u : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((((cong (B : mat_Point)) (U : mat_Point)) (u : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(W : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (B : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ w : mat_Point. ((mat_and (((betS (u : mat_Point)) (b : mat_Point)) (w : mat_Point))) ((((cong (b : mat_Point)) (w : mat_Point)) (U : mat_Point)) (B : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (u : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (f : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (f : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (f : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (f : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ W : mat_Point. ((mat_and (((betS (U : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (W : mat_Point)) (U : mat_Point)) (B : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                                 ))))
                                           ) (ASSUME `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                                           ))))
                                     ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                                     ))))
                               ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                               ))))
                         ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
                         )))
                      ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                      ))
                    ) (MP  
                       (CONV_CONV_rule `(((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> (((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                        (MP  
                         (SPEC `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                          (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                           (SPEC `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                            (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `(((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                               (MP  
                                (SPEC `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                  (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                    (ASSUME `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                    ))))
                              ) (ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                              )))))
                       ) (ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                       )))
                  ) (MP  
                     (CONV_CONV_rule `(((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                      (MP  
                       (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                        (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                         (SPEC `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                          (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `(((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point))` 
                             (MP  
                              (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                 (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                  (ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                  ))))
                            ) (ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                            )))))
                     ) (ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                     )))
                ) (MP  
                   (CONV_CONV_rule `(((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                    (MP  
                     (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                       (SPEC `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                        (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `(((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                           (MP  
                            (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                              (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                ))))
                          ) (ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                          )))))
                   ) (ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                   )))
              ) (MP  
                 (CONV_CONV_rule `(((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                  (MP  
                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                    (SPEC `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                     (SPEC `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                      (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                       (MP  
                        (CONV_CONV_rule `(((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                         (MP  
                          (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                            (SPEC `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                              (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                              ))))
                        ) (ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                        )))))
                 ) (ASSUME `((((supp (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                 )))))))))))))))
 ;;


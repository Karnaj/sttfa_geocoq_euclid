(*lemma__angletrichotomy :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((((ltA A) B) C) D) E) F) ==> (mat_not ((((((ltA D) E) F) A) B) C))))))))`*)
let lemma__angletrichotomy =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (mat_not ((((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
         (DISCH `mat_not ((((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
          (ASSUME `mat_not ((((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
          ))
        ) (DISCH `(((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
               (DISCH `ex (\ G : mat_Point. (ex (\ H2 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H2 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H2 : mat_Point))))))))))` 
                (MP  
                 (MP  
                  (SPEC `mat_false` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ H3 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (x : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H3 : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. (ex (\ H3 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H3 : mat_Point))))))))))) ==> (return : bool)))` 
                    (SPEC `\ G : mat_Point. (ex (\ H3 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H3 : mat_Point)))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(G : mat_Point)` 
                     (DISCH `ex (\ H3 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H3 : mat_Point))))))))` 
                      (MP  
                       (MP  
                        (SPEC `mat_false` 
                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (x : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ H4 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))))))))) ==> (return : bool)))` 
                          (SPEC `\ H4 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(H4 : mat_Point)` 
                           (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))))))` 
                            (MP  
                             (MP  
                              (SPEC `mat_false` 
                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))))))) ==> (return : bool)))` 
                                (SPEC `\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(J : mat_Point)` 
                                 (DISCH `(mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `mat_false` 
                                     (SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)))` 
                                      (SPEC `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                       (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `mat_false` 
                                           (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))` 
                                            (SPEC `((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                             (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `mat_false` 
                                                 (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                  (SPEC `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)` 
                                                   (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)) ==> mat_false` 
                                                      (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `mat_false` 
                                                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                                           (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (ex__ind))))
                                                         ) (GEN `(U : mat_Point)` 
                                                            (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `mat_false` 
                                                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                                                                 (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__ind))
                                                                 ))
                                                               ) (GEN `(V : mat_Point)` 
                                                                  (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(u : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (U : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ P : mat_Point. ((mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ P : mat_Point. ((mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((tS (J : mat_Point)) (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (H4 : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (U0 : mat_Point)) (X : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))))))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (J : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (U : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (V : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (V : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H4 : mat_Point))) ((mat_or ((eq (G : mat_Point)) (J : mat_Point))) ((mat_or ((eq (H4 : mat_Point)) (J : mat_Point))) ((mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (V : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (V : mat_Point)) ==> (((((oS (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> ((((out (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)) ==> ((((col (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)) ==> ((((col (B : mat_Point)) (J : mat_Point)) (V : mat_Point)) ==> ((((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> ((((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)) ==> (((neq (B : mat_Point)) (V : mat_Point)) ==> (((neq (V : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point)) ==> (((((cong (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (v : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (v : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> ((((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (J : mat_Point)) (v : mat_Point)) ==> ((((col (v : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> ((((col (v : mat_Point)) (B : mat_Point)) (H4 : mat_Point)) ==> (((neq (B : mat_Point)) (v : mat_Point)) ==> (((neq (v : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (x : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (x : mat_Point)) ==> (((((oS (H4 : mat_Point)) (x : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (x : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (x : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> ((((out (B : mat_Point)) (H4 : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (H4 : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (J : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (H4 : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point)) ==> (((((cong (B : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V0 : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V0 : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (V0 : mat_Point)) ==> (((((oS (H4 : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V0 : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V0 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (V0 : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (V0 : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> ((((out (B : mat_Point)) (H4 : mat_Point)) (V0 : mat_Point)) ==> ((((col (B : mat_Point)) (H4 : mat_Point)) (V0 : mat_Point)) ==> ((((col (B : mat_Point)) (J : mat_Point)) (V0 : mat_Point)) ==> ((((col (V0 : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> ((((col (V0 : mat_Point)) (B : mat_Point)) (H4 : mat_Point)) ==> (((neq (B : mat_Point)) (V0 : mat_Point)) ==> (((neq (V0 : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (J : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (v : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (v : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (v : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((neq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((neq (B : mat_Point)) (u : mat_Point)) ==> (((((cong (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (x : mat_Point)) (v : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((((cong (v : mat_Point)) (x : mat_Point)) (v : mat_Point)) (x : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U0 : mat_Point)) (v : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((neq (B : mat_Point)) (U0 : mat_Point)) ==> (((((cong (v : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) (U0 : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (V : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (J : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (V : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (J : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (V : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point))) (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (G : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (G : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (J : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (J : mat_Point)) (B : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (J : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H4 : mat_Point)) (J : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (J : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H4 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (J : mat_Point)) (H4 : mat_Point))) ((neq (J : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (J : mat_Point)) (H4 : mat_Point))) ((neq (J : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (J : mat_Point)) (H4 : mat_Point))) ((neq (J : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (J : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (J : mat_Point)) (H4 : mat_Point))) ((neq (J : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H4 : mat_Point)) (G : mat_Point))) ((mat_and ((neq (J : mat_Point)) (H4 : mat_Point))) ((neq (J : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))) (((col (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((col (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (J : mat_Point)) (H4 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (J : mat_Point))) ((mat_or ((eq (H4 : mat_Point)) (J : mat_Point))) ((mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H4 : mat_Point)) (J : mat_Point))) ((mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (J : mat_Point)) (H4 : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (J : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (J : mat_Point)) (H4 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (V : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (H4 : mat_Point))) (((col (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (J : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((col (J : mat_Point)) (V : mat_Point)) (B : mat_Point))) ((mat_and (((col (V : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (V : mat_Point)) (J : mat_Point))) (((col (V : mat_Point)) (J : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (J : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (J : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (V : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (V : mat_Point)) ==> (((((oS (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (V : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point)) ==> (((((cong (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (v : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (v : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (x : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (x : mat_Point)) ==> (((((oS (H4 : mat_Point)) (x : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (x : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (x : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (x : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point)) ==> (((((cong (B : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V0 : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V0 : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((out (B : mat_Point)) (J : mat_Point)) (V0 : mat_Point)) ==> (((((oS (H4 : mat_Point)) (V0 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V0 : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (V0 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((cong (V0 : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) ==> (((((cong (V0 : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (V0 : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (v : mat_Point)) (B : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (J : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (v : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> (((neq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((neq (B : mat_Point)) (u : mat_Point)) ==> (((((cong (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (x : mat_Point)) (v : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((((cong (v : mat_Point)) (x : mat_Point)) (v : mat_Point)) (x : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U0 : mat_Point)) (v : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (J : mat_Point))) ==> (((((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) ==> (((neq (B : mat_Point)) (U0 : mat_Point)) ==> (((((cong (v : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) (U0 : mat_Point)) ==> (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (v : mat_Point)) (u : mat_Point)) (v : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (v : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (v : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (v : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (v : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (v : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (V : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (J : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (V : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__07
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (V : mat_Point)) (v : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (U : mat_Point)) (U : mat_Point)) (v : mat_Point))) ((((cong (U : mat_Point)) (V : mat_Point)) (v : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (V : mat_Point)) (U : mat_Point)) (U : mat_Point)) (v : mat_Point))) ((((cong (U : mat_Point)) (V : mat_Point)) (v : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (U : mat_Point)) (U : mat_Point)) (v : mat_Point))) ((((cong (U : mat_Point)) (V : mat_Point)) (v : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (U : mat_Point)) (U : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (U : mat_Point)) (U : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (v : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (U : mat_Point)) (U : mat_Point)) (v : mat_Point))) ((((cong (U : mat_Point)) (V : mat_Point)) (v : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) (U : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (U : mat_Point)) (U : mat_Point)) (v : mat_Point))) ((((cong (U : mat_Point)) (V : mat_Point)) (v : mat_Point)) (U : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (B : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (B : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((oS (H4 : mat_Point)) (V : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (V : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (H4 : mat_Point)) (V : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (V : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (H4 : mat_Point)) (V : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (V : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (V : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H4 : mat_Point)) (V : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (H4 : mat_Point)) (V : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (V : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (H4 : mat_Point)) (V : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (V : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (V : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((oS (H4 : mat_Point)) (V : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (V : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (V : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (J : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (U : mat_Point))) (((betS (B : mat_Point)) (U : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((oS (J : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (H4 : mat_Point)) (J : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (J : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (H4 : mat_Point)) (J : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (J : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (H4 : mat_Point)) (J : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (H4 : mat_Point)) (J : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (J : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (J : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (H4 : mat_Point)) (J : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (J : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (H4 : mat_Point)) (J : mat_Point)) (U : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (H4 : mat_Point)) (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and ((((oS (J : mat_Point)) (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((((oS (H4 : mat_Point)) (J : mat_Point)) (U : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (J : mat_Point)) (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (U0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (U0 : mat_Point)) (X : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (U0 : mat_Point)) (X : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (U0 : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (U0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (U0 : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))))) ==> (ex (\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (V0 : mat_Point))) ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (V0 : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) ((mat_and (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (U : mat_Point)) (J : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> (((neq (B : mat_Point)) (U : mat_Point)) ==> (((neq (U : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((((col (u : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (u : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> (((neq (B : mat_Point)) (u : mat_Point)) ==> (((neq (u : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (J : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (J : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((((col (U0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (U0 : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> (((neq (B : mat_Point)) (U0 : mat_Point)) ==> (((neq (U0 : mat_Point)) (B : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (u : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (u : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (u : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (U : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (U : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (U : mat_Point))) (((col (J : mat_Point)) (U : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (J : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) (P : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (J : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (x : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((mat_not (((col (B : mat_Point)) (U0 : mat_Point)) (H4 : mat_Point))) ==> ((((out (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (G : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (G : mat_Point)) ==> (((((tS (H4 : mat_Point)) (B : mat_Point)) (U0 : mat_Point)) (P : mat_Point)) ==> (((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (H4 : mat_Point)) (B : mat_Point)) (u : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (H4 : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (H4 : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (H4 : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (G : mat_Point))) (((col (U : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (G : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H4 : mat_Point))) ((mat_or ((eq (G : mat_Point)) (J : mat_Point))) ((mat_or ((eq (H4 : mat_Point)) (J : mat_Point))) ((mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (H4 : mat_Point)) (B : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((neq (H4 : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or ((eq (G : mat_Point)) (J : mat_Point))) ((mat_or ((eq (B : mat_Point)) (J : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (J : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (J : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (J : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (G : mat_Point)) (J : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (J : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (J : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (G : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (G : mat_Point))) ((mat_and (((col (J : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (J : mat_Point)) (B : mat_Point))) (((col (J : mat_Point)) (B : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (J : mat_Point))) ((mat_or ((eq (B : mat_Point)) (J : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (J : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)) ==> (! y : mat_Point. (((eq (H4 : mat_Point)) (y : mat_Point)) ==> (((betS (G : mat_Point)) (y : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((betS (G : mat_Point)) (X : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (H4 : mat_Point)) (B : mat_Point))) ==> ((eq (H4 : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (H4 : mat_Point)) (B : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (J : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H4 : mat_Point)) (B : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point)) ==> mat_false) ==> (((col (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H4 : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (H4 : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (P : mat_Point))) ((mat_and ((neq (J : mat_Point)) (G : mat_Point))) ((neq (J : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (J : mat_Point)) (G : mat_Point))) ((neq (J : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (J : mat_Point)) (G : mat_Point))) ((neq (J : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (J : mat_Point)) (G : mat_Point))) ((neq (J : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (P : mat_Point))) ((mat_and ((neq (J : mat_Point)) (G : mat_Point))) ((neq (J : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (G : mat_Point))) (((col (H4 : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (H4 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (G : mat_Point)) (H4 : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (G : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (G : mat_Point)) (H4 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((col (B : mat_Point)) (G : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (A : mat_Point))) (((col (H4 : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (J : mat_Point))) ((mat_or ((eq (H4 : mat_Point)) (J : mat_Point))) ((mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H4 : mat_Point)) (J : mat_Point))) ((mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) (((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H4 : mat_Point)) (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (J : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point))` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (H4 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (U : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (U : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (H4 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (H4 : mat_Point))) ((mat_and (((col (U : mat_Point)) (H4 : mat_Point)) (B : mat_Point))) ((mat_and (((col (H4 : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (H4 : mat_Point)) (U : mat_Point))) (((col (H4 : mat_Point)) (U : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_and (((col (U : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (U : mat_Point)) (A : mat_Point))) (((col (U : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> ((((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (H4 : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (U0 : mat_Point)) (v : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> ((((col (B : mat_Point)) (U0 : mat_Point)) (H4 : mat_Point)) ==> (((col (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (u : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (u : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (U : mat_Point)) (H4 : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (J : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (J : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (J : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (C : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (C : mat_Point))) (((col (J : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (J : mat_Point)) (B : mat_Point))) ((mat_and (((col (J : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (J : mat_Point)) (A : mat_Point))) (((col (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    lemma__3__7a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (J : mat_Point)) (H4 : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (H4 : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (H4 : mat_Point)) (G : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (H4 : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H4 : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H4 : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H4 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (H4 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H4 : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (H4 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (H4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (H4 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (H4 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H4 : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H4 : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(H4 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (U : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((cong (U : mat_Point)) (V : mat_Point)) (U : mat_Point)) (v : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)) ==> (((((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((cong (x : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. ((((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point)) ==> (((((cong (B : mat_Point)) (U0 : mat_Point)) (B : mat_Point)) (u : mat_Point)) ==> (((((cong (U0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> ((((cong (U0 : mat_Point)) (V : mat_Point)) (U0 : mat_Point)) (v : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (u : mat_Point)) (B : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (u : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (U : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((neq (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                                                                    ))))
                                                              ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                                                              ))))
                                                        ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (H4 : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
                                                        )))
                                                     ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)`
                                                     ))))
                                               ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))))`
                                   ))))
                             ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H4 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H4 : mat_Point))))))`
                             ))))
                       ) (ASSUME `ex (\ H3 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H3 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H3 : mat_Point))))))))`
                       ))))
                 ) (ASSUME `ex (\ G : mat_Point. (ex (\ H2 : mat_Point. (ex (\ J : mat_Point. ((mat_and (((betS (G : mat_Point)) (H2 : mat_Point)) (J : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (J : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (H2 : mat_Point))))))))))`
                 )))
              ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
              ))
            ) (MP  
               (MP  
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(F : mat_Point)` 
                    (SPEC `(E : mat_Point)` 
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (lemma__angleordertransitive)
                        ))))))))
                ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                )
               ) (ASSUME `(((((ltA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
               )))))))))))
 ;;


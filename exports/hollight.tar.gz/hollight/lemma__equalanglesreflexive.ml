(*lemma__equalanglesreflexive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol A) B) C) ==> ((((((congA A) B) C) A) B) C))))`*)
let lemma__equalanglesreflexive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
      (MP  
       (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
        (MP  
         (DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (MP  
           (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
            (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            )
           ) (MP  
              (MP  
               (SPEC `(C : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(C : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__equalanglestransitive)
                       ))))))))
               ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
               )
              ) (ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
              )))
         ) (MP  
            (SPEC `(A : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(C : mat_Point)` (lemma__ABCequalsCBA)))
            ) (ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
            )))
       ) (MP  
          (SPEC `(A : mat_Point)` 
           (SPEC `(B : mat_Point)` (SPEC `(C : mat_Point)` (nCol__notCol)))
          ) (MP  
             (SPEC `(A : mat_Point)` 
              (SPEC `(B : mat_Point)` 
               (SPEC `(C : mat_Point)` (nCol__not__Col)))
             ) (MP  
                (SPEC `(A : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(A : mat_Point)` (lemma__equalanglesNC))))))
                ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                )))))
     ) (MP  
        (SPEC `(C : mat_Point)` 
         (SPEC `(B : mat_Point)` 
          (SPEC `(A : mat_Point)` (lemma__ABCequalsCBA)))
        ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`)
     )))))
 ;;


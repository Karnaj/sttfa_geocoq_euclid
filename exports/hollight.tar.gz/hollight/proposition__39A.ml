(*proposition__39A :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! M : mat_Point. ((((triangle A) B) C) ==> (((((((eT A) B) C) D) B) C) ==> ((((betS A) M) C) ==> ((((out B) D) M) ==> ((((par A) D) B) C)))))))))`*)
let proposition__39A =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(M : mat_Point)` 
     (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
        (DISCH `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
         (MP  
          (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
           (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
            (MP  
             (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
              (MP  
               (DISCH `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
                (MP  
                 (MP  
                  (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                    (SPEC `\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(m : mat_Point)` 
                     (DISCH `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                      (MP  
                       (MP  
                        (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                          (SPEC `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                           (DISCH `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (m : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (m : mat_Point)) (B : mat_Point))) ((mat_or (((betS (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (m : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                              (DISCH `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                               (MP  
                                (DISCH `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                      (DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                       (MP  
                                        (DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                         (MP  
                                          (DISCH `((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `(neq (C : mat_Point)) (m : mat_Point)` 
                                               (MP  
                                                (DISCH `ex (\ H17 : mat_Point. ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (H17 : mat_Point))) ((((cong (m : mat_Point)) (H17 : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (x : mat_Point))) ((((cong (m : mat_Point)) (x : mat_Point)) (m : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ H18 : mat_Point. ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                     (SPEC `\ H18 : mat_Point. ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                                       (ex__ind))))
                                                   ) (GEN `(H18 : mat_Point)` 
                                                      (DISCH `(mat_and (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                            (DISCH `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((betS (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                               (MP  
                                                                (DISCH `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (m : mat_Point)) (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) ==> mat_false) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (x : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (m : mat_Point))) ((mat_or ((eq (C : mat_Point)) (H18 : mat_Point))) ((mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (m : mat_Point)) (m : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (m : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (m : mat_Point)) (C : mat_Point))) ((mat_or ((eq (m : mat_Point)) (m : mat_Point))) ((mat_or ((eq (C : mat_Point)) (m : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (m : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((betS (m : mat_Point)) (m : mat_Point)) (C : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (H18 : mat_Point)) (H18 : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (H18 : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H18 : mat_Point)) (m : mat_Point))) ((mat_or ((eq (H18 : mat_Point)) (H18 : mat_Point))) ((mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (H18 : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (H18 : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H18 : mat_Point)) (A : mat_Point))) ((mat_or ((eq (H18 : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (H18 : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (H18 : mat_Point)) (A : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))))) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (m : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__deZolt1
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (E : mat_Point)) ==> (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> (((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((((out (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> ((((out (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) ==> ((((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((((((eT (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((((out (B : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((par (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ D0 : mat_Point. (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (D0 : mat_Point)) (M : mat_Point)) ==> (((((((eT (D0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (D0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((out (B : mat_Point)) (M : mat_Point)) (D0 : mat_Point)) ==> ((((out (B : mat_Point)) (D0 : mat_Point)) (E : mat_Point)) ==> ((((par (A : mat_Point)) (D0 : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (m : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (H18 : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (B : mat_Point)) (H18 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))) (mat_not (((betS (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and (mat_not (((betS (m : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ((mat_and (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point)))) (mat_not (((betS (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (m : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (m : mat_Point)))) (mat_not (((betS (m : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__deZolt1
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__ETtransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__37
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (H18 : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((neq (H18 : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((neq (H18 : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((neq (H18 : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((neq (H18 : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((neq (H18 : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (H18 : mat_Point)) (A : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H18 : mat_Point)) (A : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (E : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (H18 : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H18 : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (H18 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H18 : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__27B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (x : mat_Point))) (((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (X : mat_Point))) (((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H18 : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H18 : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H18 : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H18 : mat_Point)) (H18 : mat_Point))) ((mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (H18 : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (H18 : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (H18 : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (H18 : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (H18 : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H18 : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H18 : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H18 : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (m : mat_Point))) (((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (H18 : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H18 : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((neq (H18 : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H18 : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (H18 : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H18 : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H18 : mat_Point)) (m : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (H18 : mat_Point)) (A : mat_Point))) ((mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (H18 : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H18 : mat_Point)) (m : mat_Point))) (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (m : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)) ==> (((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> (((((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)) ==> (((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> (((((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)) ==> (((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> (((((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)) ==> (((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> (((((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H18 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((((congA (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((congA (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)) (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (m : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (m : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__15a
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) (((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (m : mat_Point)) (C : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (m : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (m : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (m : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (m : mat_Point))) ((mat_or ((eq (C : mat_Point)) (m : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (m : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((betS (m : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (m : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (m : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((betS (m : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (m : mat_Point)) (m : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (H18 : mat_Point))) ((mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point))) (((betS (H18 : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    postulate__Euclid5
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (m : mat_Point))) ((mat_or ((eq (C : mat_Point)) (H18 : mat_Point))) ((mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (m : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (m : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (M : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))) (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (m : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (m : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (m : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (m : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H18 : mat_Point)) (m : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (H18 : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (H18 : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (m : mat_Point)) (H18 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (C : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))) (((col (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (H18 : mat_Point))) ((mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (m : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point))) ((mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (m : mat_Point)) (C : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H18 : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (H18 : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((col (m : mat_Point)) (A : mat_Point)) (H18 : mat_Point))) ((mat_and (((col (A : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) (((col (m : mat_Point)) (H18 : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (H18 : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (H18 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H18 : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (A : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (A : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (A : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (m : mat_Point)) (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (m : mat_Point)) (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (A : mat_Point)) (m : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (m : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((((cong (m : mat_Point)) (B : mat_Point)) (A : mat_Point)) (m : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (B : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                  )))
                                                                ) (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                   )))
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(m : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                 ) (ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                                                 )))))
                                                        ) (ASSUME `(mat_and (((betS (C : mat_Point)) (m : mat_Point)) (H18 : mat_Point))) ((((cong (m : mat_Point)) (H18 : mat_Point)) (m : mat_Point)) (C : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `ex (\ H17 : mat_Point. ((mat_and (((betS (C : mat_Point)) (m : mat_Point)) (H17 : mat_Point))) ((((cong (m : mat_Point)) (H17 : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                                                  ))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(m : mat_Point)` 
                                                      (SPEC `(m : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (lemma__extension))))
                                                    ) (ASSUME `(neq (C : mat_Point)) (m : mat_Point)`
                                                    )
                                                   ) (ASSUME `(neq (m : mat_Point)) (C : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(m : mat_Point)` 
                                                   (lemma__inequalitysymmetric
                                                   ))
                                                 ) (ASSUME `(neq (m : mat_Point)) (C : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (DISCH `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                    (SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                          (SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (m : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                             ))))
                                                       ) (ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (m : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (m : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(m : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__NCdistinct)))
                                                  ) (ASSUME `((nCol (A : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(m : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (nCol__notCol)))
                                             ) (MP  
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(m : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (nCol__not__Col)))
                                                ) (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(m : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (lemma__NChelper))
                                                         )))
                                                      ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                     )
                                                    ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                    )
                                                   ) (ASSUME `(neq (A : mat_Point)) (m : mat_Point)`
                                                   )))))
                                        ) (MP  
                                           (DISCH `(mat_and ((neq (m : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                               (SPEC `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                (SPEC `(neq (m : mat_Point)) (B : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (m : mat_Point)) (B : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `(neq (A : mat_Point)) (m : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (A : mat_Point)) (m : mat_Point)` 
                                                       (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                        (ASSUME `(neq (A : mat_Point)) (m : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (m : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (m : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                             ))
                                           ) (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(m : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__betweennotequal)))
                                              ) (ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                              )))))
                                     ) (MP  
                                        (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                         (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                            (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                             (or__introl))
                                           ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                           )))))
                                  ) (SPEC `(A : mat_Point)` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (eq__refl))))
                                ) (MP  
                                   (DISCH `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                       (SPEC `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                        (SPEC `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                             (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                              (SPEC `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                   (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                    (SPEC `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point)` 
                                                     (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                         (SPEC `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                           (DISCH `((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                            (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point))))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (m : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (m : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((col (B : mat_Point)) (m : mat_Point)) (A : mat_Point)))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(m : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (lemma__collinearorder)))
                                      ) (ASSUME `((col (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                      )))))
                             ) (MP  
                                (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (m : mat_Point)) (B : mat_Point))) ((mat_or (((betS (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (m : mat_Point)))))` 
                                 (SPEC `(eq (A : mat_Point)) (m : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (m : mat_Point)) (B : mat_Point))) ((mat_or (((betS (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (m : mat_Point))))` 
                                    (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (m : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (m : mat_Point)))` 
                                       (SPEC `(eq (m : mat_Point)) (B : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `(mat_or (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (m : mat_Point))` 
                                          (SPEC `((betS (m : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                             (SPEC `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                              (or__introl))
                                            ) (ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                                            )))))))))
                       ) (ASSUME `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point))`
                       ))))
                 ) (ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (B : mat_Point))) ((((cong (m : mat_Point)) (A : mat_Point)) (m : mat_Point)) (B : mat_Point))))`
                 ))
               ) (MP  
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(A : mat_Point)` (proposition__10))
                  ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))
             ) (MP  
                (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                    (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                          (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                            (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                 (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                  (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                       (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                        (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                             (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                              (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                               (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                  ))
                ) (MP  
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
                   ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                   )))))
          ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
          ))))))))))
 ;;


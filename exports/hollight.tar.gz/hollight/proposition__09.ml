(*proposition__09 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol B) A) C) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA B) A) X) X) A) C)) ((((inAngle B) A) C) X)))))))`*)
let proposition__09 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
      (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
       (MP  
        (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
         (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
          (MP  
           (DISCH `ex (\ E : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
            (MP  
             (MP  
              (SPEC `ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                (SPEC `\ E : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(E : mat_Point)` 
                 (DISCH `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                  (MP  
                   (MP  
                    (SPEC `ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))` 
                     (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                      (SPEC `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                       (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `(((eq (B : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                          (DISCH `mat_not ((eq (B : mat_Point)) (E : mat_Point))` 
                           (MP  
                            (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))` 
                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((((cong (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                 (SPEC `\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)))
                                )
                               ) (GEN `(F : mat_Point)` 
                                  (DISCH `(mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))` 
                                      (SPEC `(((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                       (SPEC `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                        (DISCH `(((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                           (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((eq (F : mat_Point)) (F : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                              (DISCH `(eq (F : mat_Point)) (F : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                         (DISCH `mat_not (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                          (MP  
                                                           (DISCH `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `(((eq (A : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                              (DISCH `mat_not ((eq (A : mat_Point)) (F : mat_Point))` 
                                                               (MP  
                                                                (DISCH `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                                   (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (Y : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (Y : mat_Point)))))))) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((inAngle (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (Y : mat_Point))) (((betS (x : mat_Point)) (F : mat_Point)) (Y : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (Y : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (Y : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (Y : mat_Point))) (((betS (X : mat_Point)) (F : mat_Point)) (Y : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (x : mat_Point)))) ==> (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (Y : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (Y : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (Y : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (Y : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (F : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((congA (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. (((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x4 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x3 : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and ((((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                  ) (
                                                                  ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))`
                                                                  )))))))))))
                                                                  )))
                                                                ) (MP  
                                                                   (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (F : mat_Point))) ==> (((out (A : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (F : mat_Point))) (((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (F : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `mat_not ((eq (A : mat_Point)) (F : mat_Point))`
                                                                   ))))
                                                             ) (DISCH `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                                  (DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                           ) (MP  
                                                              (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                               (MP  
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__ray4
                                                                   )))
                                                                ) (MP  
                                                                   (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                   ))))
                                                              ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                              ))))
                                                        ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (F : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (F : mat_Point)) (E : mat_Point))) ((mat_or (((betS (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (F : mat_Point))))))) ==> mat_false` 
                                                             (DISCH `((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                              (MP  
                                                               (DISCH `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (DISCH `(mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (F : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                   ))))
                                                                 ) (MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))) (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                               ) (MP  
                                                                  (DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((col (E : mat_Point)) (F : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                  )))))
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (F : mat_Point)) (E : mat_Point))) ((mat_or (((betS (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))))` 
                                                                (SPEC `(eq (B : mat_Point)) (F : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `(mat_or ((eq (F : mat_Point)) (E : mat_Point))) ((mat_or (((betS (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (F : mat_Point))))` 
                                                                   (SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                   (SPEC `(eq (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                   (SPEC `((betS (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                   (SPEC `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                  )))))))))
                                                      ) (MP  
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (lemma__congruencesymmetric
                                                             ))))
                                                         ) (ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (DISCH `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                           (SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                            (SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                             (DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                              (ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((((cong (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(E : mat_Point)` 
                                                           (SPEC `(F : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(F : mat_Point)` 
                                                              (lemma__doublereverse
                                                              ))))
                                                          ) (ASSUME `(((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(E : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (lemma__congruencesymmetric
                                                         ))))
                                                     ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                     )))
                                                ) (SPEC `(F : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (cn__congruencereflexive)
                                                   ))))
                                             ) (SPEC `(F : mat_Point)` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (eq__refl)))))
                                          ) (SPEC `(B : mat_Point)` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (eq__refl))))))
                                    ) (ASSUME `(mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point))`
                                    ))))
                              ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((cong (F : mat_Point)) (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))`
                              ))
                            ) (MP  
                               (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (E : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((((cong (X : mat_Point)) (B : mat_Point)) (X : mat_Point)) (E : mat_Point)))))` 
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(B : mat_Point)` (proposition__10)))
                               ) (ASSUME `mat_not ((eq (B : mat_Point)) (E : mat_Point))`
                               ))))
                         ) (DISCH `(eq (B : mat_Point)) (E : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                              (DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                               (MP  
                                (DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                 (MP  
                                  (DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (MP  
                                    (DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                       (MP  
                                        (DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                         (MP  
                                          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (col__nCol__False)))
                                               ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                               )
                                              ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                              ))
                                            ) (MP  
                                               (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                    (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                          (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                           (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__collinearorder))
                                                   )
                                                  ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (not__nCol__Col))))
                                             ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (col__nCol__False)))
                                                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  )
                                                 ) (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (lemma__collinear4)
                                                         )))
                                                      ) (ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                     )
                                                    ) (ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                    ))))))
                                        ) (MP  
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (lemma__inequalitysymmetric))
                                           ) (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                           )))
                                      ) (MP  
                                         (MP  
                                          (MP  
                                           (MP  
                                            (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (E : mat_Point)))))` 
                                             (MP  
                                              (MP  
                                               (CONV_CONV_rule `((eq (B : mat_Point)) (E : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (E : mat_Point)))))))` 
                                                (SPEC `(B : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `((((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (E : mat_Point))) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) ==> ((((col (E : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> (mat_not ((eq (A : mat_Point)) (E : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((col (E : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((neq (A : mat_Point)) (E : mat_Point)))))))))` 
                                                   (SPEC `\ B0 : mat_Point. ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (E : mat_Point)) ==> ((((col (E : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((neq (A : mat_Point)) (E : mat_Point)))))))` 
                                                    (SPEC `(E : mat_Point)` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (eq__ind__r))))
                                                  ) (DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `mat_not ((eq (A : mat_Point)) (E : mat_Point))` 
                                                      (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                       (DISCH `((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                        (DISCH `((col (E : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                         (ASSUME `mat_not ((eq (A : mat_Point)) (E : mat_Point))`
                                                         ))))))))
                                               ) (ASSUME `(eq (B : mat_Point)) (E : mat_Point)`
                                               )
                                              ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                              ))
                                            ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                            )
                                           ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                           )
                                          ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                          )
                                         ) (ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                         )))
                                    ) (MP  
                                       (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                            (SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                             (DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                  (SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                   (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                        (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                              (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                (ASSUME `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                         ))
                                       ) (MP  
                                          (SPEC `(E : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (lemma__collinearorder)))
                                          ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                          ))))
                                  ) (MP  
                                     (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                          (SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                           (DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                (SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                 (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                      (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                             (DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                              (ASSUME `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                             ))))
                                       ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                       ))
                                     ) (MP  
                                        (SPEC `(E : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (lemma__collinearorder)))
                                        ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                        ))))
                                ) (MP  
                                   (SPEC `(E : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (lemma__rayimpliescollinear)))
                                   ) (ASSUME `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                   ))))
                             ) (MP  
                                (SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                 (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                    (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                       (SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (B : mat_Point)) (E : mat_Point)`
                                      )))))))))
                   ) (ASSUME `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                   ))))
             ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
             ))
           ) (MP  
              (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
               (MP  
                (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(A : mat_Point)` (lemma__layoff)))))
                ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`))
              ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`))))
        ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
             (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
              (MP  
               (MP  
                (SPEC `(C : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(B : mat_Point)` (col__nCol__False)))
                ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                )
               ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
               )))
            ) (MP  
               (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                (SPEC `(eq (B : mat_Point)) (A : mat_Point)` (or__intror))
               ) (MP  
                  (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                   (SPEC `(eq (B : mat_Point)) (C : mat_Point)` (or__intror))
                  ) (MP  
                     (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                      (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                       (or__introl))
                     ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`))))))))
     ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
        (MP  
         (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
            (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
             (MP  
              (MP  
               (SPEC `(C : mat_Point)` 
                (SPEC `(A : mat_Point)` 
                 (SPEC `(B : mat_Point)` (col__nCol__False)))
               ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
               )
              ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
              )))
           ) (MP  
              (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
               (SPEC `(eq (B : mat_Point)) (A : mat_Point)` (or__introl))
              ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`)))
         ) (MP  
            (SPEC `(A : mat_Point)` 
             (SPEC `(B : mat_Point)` (lemma__equalitysymmetric))
            ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))))))))
 ;;


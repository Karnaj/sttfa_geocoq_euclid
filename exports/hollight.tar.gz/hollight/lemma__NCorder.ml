(*lemma__NCorder :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol A) B) C) ==> ((mat_and (((nCol B) A) C)) ((mat_and (((nCol B) C) A)) ((mat_and (((nCol C) A) B)) ((mat_and (((nCol A) C) B)) (((nCol C) B) A))))))))`*)
let lemma__NCorder =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
      (DISCH `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
       (MP  
        (CONV_CONV_rule `((((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
         (DISCH `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
          (MP  
           (CONV_CONV_rule `((((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
            (DISCH `mat_not (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
             (MP  
              (CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
               (DISCH `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                (MP  
                 (CONV_CONV_rule `((((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                  (DISCH `mat_not (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                      (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                       (conj))
                     ) (MP  
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(B : mat_Point)` (nCol__notCol)))
                        ) (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                        ))
                    ) (MP  
                       (MP  
                        (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                         (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                          (conj))
                        ) (MP  
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(B : mat_Point)` (nCol__notCol)))
                           ) (ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                           ))
                       ) (MP  
                          (MP  
                           (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                            (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                             (conj))
                           ) (MP  
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(C : mat_Point)` (nCol__notCol)))
                              ) (ASSUME `mat_not (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                              ))
                          ) (MP  
                             (MP  
                              (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                               (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                (conj))
                              ) (MP  
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(A : mat_Point)` (nCol__notCol)))
                                 ) (ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                 ))
                             ) (MP  
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(C : mat_Point)` (nCol__notCol)))
                                ) (ASSUME `mat_not (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                )))))))
                 ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                    (MP  
                     (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                        (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                        )
                       ) (MP  
                          (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(A : mat_Point)` 
                             (SPEC `(B : mat_Point)` (not__nCol__Col))))
                          ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                             (MP  
                              (MP  
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(A : mat_Point)` (col__nCol__False)))
                               ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                               )
                              ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                              )))))
                     ) (MP  
                        (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                             (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                              (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                    (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                         (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                          ))
                        ) (MP  
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(C : mat_Point)` (lemma__collinearorder))
                            )
                           ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                           )))))))
              ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                 (MP  
                  (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                     (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                     )
                    ) (MP  
                       (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(B : mat_Point)` (not__nCol__Col))))
                       ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (MP  
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` (col__nCol__False)))
                            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            )
                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                           )))))
                  ) (MP  
                     (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                      (MP  
                       (MP  
                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                          (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                           (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                            (MP  
                             (MP  
                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                 (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                      (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                              (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )))
                                         ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                             ))))
                       ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                       ))
                     ) (MP  
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(A : mat_Point)` (lemma__collinearorder)))
                        ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                        )))))))
           ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
              (MP  
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                  (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                  )
                 ) (MP  
                    (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` 
                       (SPEC `(B : mat_Point)` (not__nCol__Col))))
                    ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (MP  
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (col__nCol__False)))
                         ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                         )
                        ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                        )))))
               ) (MP  
                  (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                   (MP  
                    (MP  
                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                       (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                   (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                          (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                ))))
                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                          ))))
                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                    ))
                  ) (MP  
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(A : mat_Point)` 
                       (SPEC `(C : mat_Point)` (lemma__collinearorder)))
                     ) (ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                     )))))))
        ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
           (MP  
            (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (MP  
              (CONV_CONV_rule `(((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
               (ASSUME `mat_not (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
               )
              ) (MP  
                 (CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(A : mat_Point)` 
                    (SPEC `(B : mat_Point)` (not__nCol__Col))))
                 ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (MP  
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (col__nCol__False)))
                      ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      )
                     ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     )))))
            ) (MP  
               (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                (MP  
                 (MP  
                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                    (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                     (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                      (MP  
                       (MP  
                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                          (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                           (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                            (MP  
                             (MP  
                              (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                      (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                       (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                        (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                        )))
                                   ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                             ))))
                       ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                       ))))
                 ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                 ))
               ) (MP  
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` (lemma__collinearorder)))
                  ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                  )))))))
     ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (MP  
           (MP  
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` (col__nCol__False)))
            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            )
           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           ))
         ) (MP  
            (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
             (MP  
              (MP  
               (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                   (MP  
                    (MP  
                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                       (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                             (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                              (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                     (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                          ))))
                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                    ))))
              ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
              ))
            ) (MP  
               (SPEC `(C : mat_Point)` 
                (SPEC `(A : mat_Point)` 
                 (SPEC `(B : mat_Point)` (lemma__collinearorder)))
               ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
               )))))))))
 ;;


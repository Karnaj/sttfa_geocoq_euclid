(*lemma__lessthantransitive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((lt A) B) C) D) ==> (((((lt C) D) E) F) ==> ((((lt A) B) E) F))))))))`*)
let lemma__lessthantransitive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (DISCH `(((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
        (MP  
         (CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
          (DISCH `ex (\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
           (MP  
            (MP  
             (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
               (SPEC `\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(G : mat_Point)` 
                (DISCH `(mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                    (SPEC `(((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                     (SPEC `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                      (DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (CONV_CONV_rule `((((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                         (DISCH `ex (\ H5 : mat_Point. ((mat_and (((betS (E : mat_Point)) (H5 : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (H5 : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                          (MP  
                           (MP  
                            (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ H6 : mat_Point. ((mat_and (((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                              (SPEC `\ H6 : mat_Point. ((mat_and (((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(H6 : mat_Point)` 
                               (DISCH `(mat_and (((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                   (SPEC `(((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (SPEC `((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point)` 
                                     (DISCH `(((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (MP  
                                       (DISCH `(neq (E : mat_Point)) (H6 : mat_Point)` 
                                        (MP  
                                         (DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                          (MP  
                                           (DISCH `ex (\ K : mat_Point. ((mat_and (((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))) ((((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (E : mat_Point)) (H6 : mat_Point)) (x : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (C : mat_Point)) (G : mat_Point))) ==> (return : bool))) ==> ((ex (\ K : mat_Point. ((mat_and (((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))) ((((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))))) ==> (return : bool)))` 
                                                (SPEC `\ K : mat_Point. ((mat_and (((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))) ((((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)))` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (ex__ind))))
                                              ) (GEN `(K : mat_Point)` 
                                                 (DISCH `(mat_and (((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))) ((((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                     (SPEC `(((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                      (SPEC `((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)` 
                                                       (DISCH `(((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((cong (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(mat_or (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ((mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)))` 
                                                            (MP  
                                                             (DISCH `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                              (MP  
                                                               (DISCH `((betS (E : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> ((((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                  (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                   (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (K : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__3__6b
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point)`
                                                                  )))
                                                             ) (MP  
                                                                (DISCH `(mat_or (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ((mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)))` 
                                                                 (MP  
                                                                  (DISCH `(mat_or (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ((mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (G : mat_Point)) ==> (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ==> mat_false) ==> (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ==> mat_false) ==> (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (G : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (G : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (G : mat_Point))) (((betS (C : mat_Point)) (G : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (G : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (G : mat_Point))) (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H6 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (H6 : mat_Point)) (K : mat_Point)) ==> ((((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point)) ==> (((((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (E : mat_Point)) (H6 : mat_Point)) ==> ((((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)) ==> ((((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H6 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(H6 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (E : mat_Point)) (K : mat_Point)) (F : mat_Point)) ==> (((((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (E : mat_Point)) (K : mat_Point)) ==> ((((out (E : mat_Point)) (K : mat_Point)) (K : mat_Point)) ==> ((((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (K : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (K : mat_Point)) ==> ((((betS (E : mat_Point)) (x : mat_Point)) (F : mat_Point)) ==> (((((cong (E : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (E : mat_Point)) (x : mat_Point)) ==> ((((out (E : mat_Point)) (x : mat_Point)) (K : mat_Point)) ==> ((((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (x : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ H22 : mat_Point. ((((betS (E : mat_Point)) (H22 : mat_Point)) (F : mat_Point)) ==> (((((cong (E : mat_Point)) (H22 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (E : mat_Point)) (H22 : mat_Point)) ==> ((((out (E : mat_Point)) (H22 : mat_Point)) (K : mat_Point)) ==> ((((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H22 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (E : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (H6 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (H6 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ J : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point))) ((((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((((cong (D : mat_Point)) (x : mat_Point)) (H6 : mat_Point)) (K : mat_Point))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point))) ((((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ J : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point))) ((((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point))) ((((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (J : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (J : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (G : mat_Point)) (D : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ==> mat_false) ==> (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ==> mat_false) ==> (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (J : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (J : mat_Point)) (G : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (J : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (J : mat_Point)) (G : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (J : mat_Point)) (G : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)) ==> (((((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point)) ==> ((((out (C : mat_Point)) (D : mat_Point)) (J : mat_Point)) ==> (((((cong (C : mat_Point)) (J : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> (((((cong (C : mat_Point)) (J : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((betS (G : mat_Point)) (D : mat_Point)) (J : mat_Point)) ==> (((neq (G : mat_Point)) (J : mat_Point)) ==> ((neq (J : mat_Point)) (G : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) ==> (((((cong (D : mat_Point)) (G : mat_Point)) (H6 : mat_Point)) (K : mat_Point)) ==> ((((out (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) ==> (((((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> (((((cong (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((betS (G : mat_Point)) (D : mat_Point)) (G : mat_Point)) ==> (((neq (G : mat_Point)) (G : mat_Point)) ==> ((neq (G : mat_Point)) (G : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (G : mat_Point)) ==> ((((betS (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (D : mat_Point)) (x : mat_Point)) (H6 : mat_Point)) (K : mat_Point)) ==> ((((out (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((betS (G : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (G : mat_Point)) (x : mat_Point)) ==> ((neq (x : mat_Point)) (G : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ J0 : mat_Point. ((((betS (C : mat_Point)) (D : mat_Point)) (J0 : mat_Point)) ==> (((((cong (D : mat_Point)) (J0 : mat_Point)) (H6 : mat_Point)) (K : mat_Point)) ==> ((((out (C : mat_Point)) (D : mat_Point)) (J0 : mat_Point)) ==> (((((cong (C : mat_Point)) (J0 : mat_Point)) (E : mat_Point)) (K : mat_Point)) ==> (((((cong (C : mat_Point)) (J0 : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((betS (G : mat_Point)) (D : mat_Point)) (J0 : mat_Point)) ==> (((neq (G : mat_Point)) (J0 : mat_Point)) ==> ((neq (J0 : mat_Point)) (G : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (G : mat_Point)) (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (G : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (G : mat_Point)) (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (G : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (J : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (J : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (J : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (J : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((neq (G : mat_Point)) (J : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (J : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (J : mat_Point)) (E : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H6 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (J : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (J : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (J : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point))) ((((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (C : mat_Point)) (D : mat_Point)) (J : mat_Point))) ((((cong (D : mat_Point)) (J : mat_Point)) (H6 : mat_Point)) (K : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H6 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H6 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H6 : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H6 : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H6 : mat_Point)) (K : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H6 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ((mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(mat_or (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ((mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)))`
                                                                  ))
                                                                ) (ASSUME `(mat_or (((betS (E : mat_Point)) (K : mat_Point)) (H6 : mat_Point))) ((mat_or ((eq (H6 : mat_Point)) (K : mat_Point))) (((betS (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)))`
                                                                )))
                                                           ) (MP  
                                                              (SPEC `(K : mat_Point)` 
                                                               (SPEC `(H6 : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (lemma__ray1
                                                                 )))
                                                              ) (ASSUME `((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point)`
                                                              )))
                                                         ) (MP  
                                                            (MP  
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(G : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(K : mat_Point)` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (lemma__congruencetransitive
                                                                   ))))))
                                                             ) (ASSUME `(((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                             )
                                                            ) (ASSUME `(((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                            )))))
                                                   ) (ASSUME `(mat_and (((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))) ((((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))`
                                                   ))))
                                             ) (ASSUME `ex (\ K : mat_Point. ((mat_and (((out (E : mat_Point)) (H6 : mat_Point)) (K : mat_Point))) ((((cong (E : mat_Point)) (K : mat_Point)) (C : mat_Point)) (G : mat_Point))))`
                                             ))
                                           ) (MP  
                                              (MP  
                                               (SPEC `(G : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(H6 : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (lemma__layoff))))
                                               ) (ASSUME `(neq (E : mat_Point)) (H6 : mat_Point)`
                                               )
                                              ) (ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                              )))
                                         ) (MP  
                                            (DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                (SPEC `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                 (SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                      (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(neq (C : mat_Point)) (G : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (C : mat_Point)) (G : mat_Point)` 
                                                        (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                         (ASSUME `(neq (C : mat_Point)) (G : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (G : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(G : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (lemma__betweennotequal)))
                                               ) (ASSUME `((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point)`
                                               ))))
                                       ) (MP  
                                          (DISCH `(mat_and ((neq (H6 : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (E : mat_Point)) (H6 : mat_Point)` 
                                              (SPEC `(mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                               (SPEC `(neq (H6 : mat_Point)) (F : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (H6 : mat_Point)) (F : mat_Point)` 
                                                (DISCH `(mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (E : mat_Point)) (H6 : mat_Point)` 
                                                    (SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                     (SPEC `(neq (E : mat_Point)) (H6 : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (E : mat_Point)) (H6 : mat_Point)` 
                                                      (DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                       (ASSUME `(neq (E : mat_Point)) (H6 : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((neq (H6 : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H6 : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))`
                                            ))
                                          ) (MP  
                                             (SPEC `(F : mat_Point)` 
                                              (SPEC `(H6 : mat_Point)` 
                                               (SPEC `(E : mat_Point)` 
                                                (lemma__betweennotequal)))
                                             ) (ASSUME `((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point)`
                                             ))))))
                                 ) (ASSUME `(mat_and (((betS (E : mat_Point)) (H6 : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (H6 : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                 ))))
                           ) (ASSUME `ex (\ H5 : mat_Point. ((mat_and (((betS (E : mat_Point)) (H5 : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (H5 : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                           )))
                        ) (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                        ))))
                  ) (ASSUME `(mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                  ))))
            ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((betS (C : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
            )))
         ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))))
 ;;


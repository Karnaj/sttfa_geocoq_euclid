(*proposition__15 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((betS A) E) B) ==> ((((betS C) E) D) ==> ((((nCol A) E) C) ==> ((mat_and ((((((congA A) E) C) D) E) B)) ((((((congA C) E) B) A) E) D)))))))))`*)
let proposition__15 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
      (DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
       (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
          (MP  
           (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
            (MP  
             (DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
              (MP  
               (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `((((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                  (DISCH `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                   (MP  
                    (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                     (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                        (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                           (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (DISCH `((out (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                              (MP  
                               (DISCH `((out (E : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                (MP  
                                 (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `((mat_and (((out (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                    (DISCH `((((supp (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                     (MP  
                                      (DISCH `((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (CONV_CONV_rule `((mat_and (((out (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                         (DISCH `((((supp (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                            (DISCH `mat_not (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                             (MP  
                                              (DISCH `(((((congA (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `((((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                   (DISCH `mat_not (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                    (MP  
                                                     (DISCH `(((((congA (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `(((eq (E : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                (DISCH `mat_not ((eq (E : mat_Point)) (C : mat_Point))` 
                                                                 (MP  
                                                                  (DISCH `((out (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((out (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `((((supp (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((out (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `((((supp (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__supplements
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((((supp (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (CONV_CONV_rule `(mat_not ((eq (E : mat_Point)) (C : mat_Point))) ==> (((out (E : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `mat_not ((eq (E : mat_Point)) (C : mat_Point))`
                                                                  ))))
                                                               ) (DISCH `(eq (E : mat_Point)) (C : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (E : mat_Point)) (C : mat_Point)`
                                                                   )))))))
                                                             ) (MP  
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                ) (ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                               ) (ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                              )))
                                                         ) (MP  
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(E : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (lemma__ABCequalsCBA
                                                               )))
                                                            ) (MP  
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (nCol__notCol
                                                                  )))
                                                               ) (ASSUME `mat_not (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                               ))))
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                           ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((((congA (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (lemma__ABCequalsCBA
                                                           )))
                                                        ) (MP  
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (nCol__notCol))
                                                            )
                                                           ) (ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                           )))))
                                                  ) (DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                       (DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                          (MP  
                                                           (DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `(((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                (ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                )
                                                               ) (MP  
                                                                  (CONV_CONV_rule `((((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                  ) (
                                                                  DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                   )))))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                   ))))
                                                           ) (MP  
                                                              (CONV_CONV_rule `((((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (not__nCol__Col
                                                                  ))))
                                                              ) (DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                  ))))))
                                                         ) (MP  
                                                            (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                (SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                 (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                              ))
                                                            ) (MP  
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (lemma__collinearorder
                                                                  )))
                                                               ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                               )))))
                                                      ) (MP  
                                                         (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                          (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                           (or__intror))
                                                         ) (MP  
                                                            (SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                              (or__intror))
                                                            ) (MP  
                                                               (SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                (SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                   (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                   (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                  )))))))))
                                                ) (MP  
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(E : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (lemma__supplements
                                                               ))))))))))
                                                     ) (ASSUME `(((((congA (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                     )
                                                    ) (ASSUME `((((supp (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                    )
                                                   ) (ASSUME `((((supp (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (lemma__ABCequalsCBA)))
                                                 ) (MP  
                                                    (SPEC `(D : mat_Point)` 
                                                     (SPEC `(E : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (nCol__notCol)))
                                                    ) (ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                    )))))
                                           ) (DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                              (MP  
                                               (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                                                (DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `(((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                           (ASSUME `mat_not (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                           )
                                                          ) (MP  
                                                             (CONV_CONV_rule `((((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(E : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (not__nCol__Col
                                                                 ))))
                                                             ) (DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                 )))))
                                                        ) (MP  
                                                           (DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                (SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (lemma__collinearorder
                                                                 )))
                                                              ) (ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (not__nCol__Col)
                                                            )))
                                                         ) (DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (col__nCol__False
                                                                 )))
                                                              ) (ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                              )
                                                             ) (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                                ))))))
                                                    ) (MP  
                                                       (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                           (SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                            (SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                  (SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__collinearorder
                                                             )))
                                                          ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                          (SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                (SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (lemma__collinearorder
                                                           )))
                                                        ) (ASSUME `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                        )))))
                                               ) (MP  
                                                  (SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                                   (SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                    (or__intror))
                                                  ) (MP  
                                                     (SPEC `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                      (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                       (or__intror))
                                                     ) (MP  
                                                        (SPEC `(mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                         (SPEC `(eq (E : mat_Point)) (D : mat_Point)` 
                                                          (or__intror))
                                                        ) (MP  
                                                           (SPEC `(mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                            (SPEC `((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                             (or__intror))
                                                           ) (MP  
                                                              (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                               (SPEC `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                (or__introl))
                                                              ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                              ))))))))))
                                        ) (MP  
                                           (MP  
                                            (SPEC `((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((out (E : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                              (conj))
                                            ) (ASSUME `((out (E : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                            )
                                           ) (ASSUME `((betS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                           )))
                                      ) (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(E : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (axiom__betweennesssymmetry)))
                                         ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                         ))))
                                   ) (MP  
                                      (MP  
                                       (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                        (SPEC `((out (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                         (conj))
                                       ) (ASSUME `((out (E : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                       )
                                      ) (ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                      )))
                                 ) (MP  
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(A : mat_Point)` 
                                       (axiom__betweennesssymmetry)))
                                    ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(E : mat_Point)` (lemma__ray4)))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                       (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                           (or__introl))
                                         ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                         )))
                                  ) (ASSUME `(neq (E : mat_Point)) (B : mat_Point)`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(D : mat_Point)` 
                                   (SPEC `(E : mat_Point)` (lemma__ray4)))
                                 ) (MP  
                                    (SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                     (SPEC `((betS (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                      (or__intror))
                                    ) (MP  
                                       (SPEC `((betS (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                        (SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                         (or__introl))
                                       ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                       )))
                                ) (ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                ))))
                          ) (SPEC `(C : mat_Point)` 
                             (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
                       ) (SPEC `(B : mat_Point)` 
                          (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
                    ) (SPEC `(D : mat_Point)` 
                       (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
                 ) (DISCH `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                    (MP  
                     (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                      (DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                         (MP  
                          (DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                             (DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                              (MP  
                               (DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                  (MP  
                                   (DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (MP  
                                     (DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (MP  
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(E : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (col__nCol__False)))
                                        ) (ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                        )
                                       ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                       ))
                                     ) (MP  
                                        (DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                             (SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                              (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                   (SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                    (DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                         (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                          (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                               (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                 (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                 )))
                                                            ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))))`
                                          ))
                                        ) (MP  
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (lemma__collinearorder)))
                                           ) (ASSUME `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                           ))))
                                   ) (MP  
                                      (CONV_CONV_rule `((((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(E : mat_Point)` 
                                          (not__nCol__Col))))
                                      ) (DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (col__nCol__False)))
                                           ) (ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                           )
                                          ) (MP  
                                             (MP  
                                              (MP  
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(D : mat_Point)` 
                                                   (lemma__collinear4))))
                                               ) (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                               )
                                              ) (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                              )
                                             ) (ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                             ))))))
                                 ) (MP  
                                    (DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                         (SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                              (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                               (SPEC `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                    (SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                     (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                      (DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                          (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                           (SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                            (DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                             (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)))))`
                                      ))
                                    ) (MP  
                                       (SPEC `(D : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(E : mat_Point)` 
                                          (lemma__collinearorder)))
                                       ) (ASSUME `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                       ))))
                               ) (MP  
                                  (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                       (SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                             (SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                   (SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                    (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                          (DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                           (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                                    ))
                                  ) (MP  
                                     (SPEC `(D : mat_Point)` 
                                      (SPEC `(E : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (lemma__collinearorder)))
                                     ) (ASSUME `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                     )))))
                            ) (MP  
                               (SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                (SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                   (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `(mat_or (((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                      (SPEC `(eq (E : mat_Point)) (D : mat_Point)` 
                                       (or__intror))
                                     ) (MP  
                                        (SPEC `(mat_or (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                         (SPEC `((betS (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                            (SPEC `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                             (or__introl))
                                           ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                           )))))))
                          ) (MP  
                             (CONV_CONV_rule `((((nCol (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(E : mat_Point)` (not__nCol__Col))))
                             ) (DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(D : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(E : mat_Point)` 
                                     (col__nCol__False)))
                                  ) (ASSUME `((nCol (E : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                  )
                                 ) (MP  
                                    (MP  
                                     (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(E : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (lemma__collinear4))))
                                      ) (ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                      )
                                     ) (ASSUME `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                     )
                                    ) (ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                    ))))))
                        ) (MP  
                           (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                               (SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                (SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                     (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                      (SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                       (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                           (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                            (SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                             (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                 (SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                  (SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                   (DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                    (ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                             ))
                           ) (MP  
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(E : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (lemma__collinearorder)))
                              ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                              )))))
                     ) (MP  
                        (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                         (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                          (or__intror))
                        ) (MP  
                           (SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                            (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                             (or__intror))
                           ) (MP  
                              (SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                               (SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                  (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (or__intror))
                                 ) (MP  
                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                     (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                      (or__introl))
                                    ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                    )))))))))
               ) (MP  
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(E : mat_Point)` (lemma__inequalitysymmetric))
                  ) (ASSUME `(neq (E : mat_Point)) (B : mat_Point)`)))
             ) (MP  
                (DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                    (SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                     (SPEC `(neq (E : mat_Point)) (B : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                      (DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                           (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                            (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                             (ASSUME `(neq (E : mat_Point)) (B : mat_Point)`)
                            ))
                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                  ))
                ) (MP  
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(E : mat_Point)` 
                     (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                   ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                   ))))
           ) (MP  
              (SPEC `(D : mat_Point)` 
               (SPEC `(E : mat_Point)` (lemma__inequalitysymmetric))
              ) (ASSUME `(neq (E : mat_Point)) (D : mat_Point)`)))
         ) (MP  
            (DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
             (MP  
              (MP  
               (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                (SPEC `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                 (SPEC `(neq (E : mat_Point)) (D : mat_Point)` (and__ind)))
               ) (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                  (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                   (MP  
                    (MP  
                     (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                      (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                       (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                        (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                         (ASSUME `(neq (E : mat_Point)) (D : mat_Point)`)))
                    ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                    ))))
              ) (ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
              ))
            ) (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(E : mat_Point)` 
                 (SPEC `(C : mat_Point)` (lemma__betweennotequal)))
               ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
               )))))))))))
 ;;

(*proposition__15a :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((betS A) E) B) ==> ((((betS C) E) D) ==> ((((nCol A) E) C) ==> ((((((congA A) E) C) D) E) B))))))))`*)
let proposition__15a =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
      (DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
       (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `(((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
          (MP  
           (MP  
            (MP  
             (ASSUME `(((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
             ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
             )
            ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
            )
           ) (ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
           ))
         ) (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
            (DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
             (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
              (MP  
               (MP  
                (SPEC `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                 (SPEC `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                  (SPEC `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                   (and__ind)))
                ) (DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                   (DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                    (ASSUME `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                    )))
               ) (MP  
                  (MP  
                   (MP  
                    (SPEC `(E : mat_Point)` 
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (proposition__15)))))
                    ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                    )
                   ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                   )
                  ) (ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                  ))))))))))))))
 ;;

(*proposition__15b :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((betS A) E) B) ==> ((((betS C) E) D) ==> ((((nCol A) E) C) ==> ((((((congA C) E) B) A) E) D))))))))`*)
let proposition__15b =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
      (DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
       (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `(((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
          (MP  
           (MP  
            (MP  
             (ASSUME `(((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))`
             ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
             )
            ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
            )
           ) (ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
           ))
         ) (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
            (DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
             (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
              (MP  
               (MP  
                (SPEC `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                 (SPEC `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                  (SPEC `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                   (and__ind)))
                ) (DISCH `(((((congA (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                   (DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                    (ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                    )))
               ) (MP  
                  (MP  
                   (MP  
                    (SPEC `(E : mat_Point)` 
                     (SPEC `(D : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` (proposition__15)))))
                    ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                    )
                   ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                   )
                  ) (ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                  ))))))))))))))
 ;;


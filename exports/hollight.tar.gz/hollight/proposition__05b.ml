(*proposition__05b :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! F : mat_Point. (! G : mat_Point. ((((isosceles A) B) C) ==> ((((betS A) B) F) ==> ((((betS A) C) G) ==> ((((((congA C) B) F) B) C) G))))))))`*)
let proposition__05b =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(F : mat_Point)` 
    (GEN `(G : mat_Point)` 
     (DISCH `((isosceles (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
       (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
        (MP  
         (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
            (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
             (MP  
              (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
               (MP  
                (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                 (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                  (MP  
                   (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                    (MP  
                     (DISCH `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                        (DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                           (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (G : mat_Point))) ==> ((((((congA (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point))` 
                                (DISCH `((((supp (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                 (MP  
                                  (DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                   (ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                   )
                                  ) (MP  
                                     (MP  
                                      (MP  
                                       (SPEC `(G : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(F : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__supplements)))))))))
                                        )
                                       ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                       )
                                      ) (ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                      )
                                     ) (ASSUME `((((supp (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                     ))))
                               ) (MP  
                                  (MP  
                                   (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                    (SPEC `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                     (conj))
                                   ) (ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                   )
                                  ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(C : mat_Point)` (lemma__ray4)))
                                 ) (MP  
                                    (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                     (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                      (or__intror))
                                    ) (MP  
                                       (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                         (or__introl))
                                       ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                       )))
                                ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                ))))
                          ) (SPEC `(B : mat_Point)` 
                             (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
                       ) (MP  
                          (MP  
                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                            (SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                             (conj))
                           ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                           )
                          ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                          )))
                     ) (MP  
                        (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` (lemma__ray4)))
                          ) (MP  
                             (SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                              (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                  (or__introl))
                                ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                ))))
                        ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                        )))
                   ) (MP  
                      (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> ((neq (C : mat_Point)) (B : mat_Point))` 
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` (lemma__inequalitysymmetric))
                       )
                      ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                      ))))
                ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                     (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (MP  
                       (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (MP  
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(A : mat_Point)` (col__nCol__False)))
                          ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                          )
                         ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                         ))
                       ) (MP  
                          (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                           (MP  
                            (MP  
                             (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                               (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                     (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                           (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                            (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                 (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                   (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                            ))
                          ) (MP  
                             (SPEC `(C : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (lemma__collinearorder)))
                             ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             )))))
                    ) (MP  
                       (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                        (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                         (or__intror))
                       ) (MP  
                          (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                           (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                            (or__intror))
                          ) (MP  
                             (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                              (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                               (or__introl))
                             ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                             )))))))
              ) (MP  
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(A : mat_Point)` (nCol__notCol)))
                 ) (MP  
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` (nCol__not__Col)))
                    ) (MP  
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(A : mat_Point)` (lemma__equalanglesNC))))
                         ))
                       ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                       ))))))
           ) (SPEC `(C : mat_Point)` 
              (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
         ) (MP  
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` (proposition__05)))
            ) (ASSUME `((isosceles (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            ))))))))))
 ;;


(*lemma__twoperpsparallel :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((per A) B) C) ==> ((((per B) C) D) ==> (((((oS A) D) B) C) ==> ((((par A) B) C) D)))))))`*)
let lemma__twoperpsparallel =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (DISCH `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (MP  
        (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (MP  
          (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
             (MP  
              (MP  
               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                 (SPEC `\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(E : mat_Point)` 
                  (DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                   (MP  
                    (MP  
                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                        (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                           (DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                            (MP  
                             (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                              (MP  
                               (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (DISCH `((per (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (DISCH `((per (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                      (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                       (MP  
                                        (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                           (MP  
                                            (DISCH `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                               (DISCH `((((supp (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                      (DISCH `(((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                               )
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                 ) (ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (DISCH `(mat_and ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                  ))))
                                                          ) (MP  
                                                             (SPEC `(D : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (lemma__parallelsymmetric
                                                                 ))))
                                                             ) (ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (proposition__28C
                                                                ))))
                                                            ) (ASSUME `(((((rT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                            )
                                                           ) (ASSUME `(((oS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                           ))))
                                                     ) (MP  
                                                        (SPEC `(B : mat_Point)` 
                                                         (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))))` 
                                                          (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__intro))))
                                                        ) (MP  
                                                           (SPEC `(C : mat_Point)` 
                                                            (CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (x : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x : mat_Point)) (Z : mat_Point)))))))))) ==> (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                             (SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__intro))))
                                                           ) (MP  
                                                              (SPEC `(E : mat_Point)` 
                                                               (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (x : mat_Point)))))))) ==> (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                (SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (Z : mat_Point))))))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__intro)
                                                                 )))
                                                              ) (MP  
                                                                 (SPEC `(D : mat_Point)` 
                                                                  (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (V : mat_Point)) (E : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (E : mat_Point)))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)) (E : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))))` 
                                                                   (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (U : mat_Point)) (V : mat_Point)) (E : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) (C : mat_Point)) (E : mat_Point)))) ==> (ex (\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (E : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((((supp (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (E : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (V : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((((supp (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))))))))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `(E : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (lemma__Euclid4)
                                                            )))))
                                                       ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                       )
                                                      ) (ASSUME `((per (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (lemma__Euclid4)))
                                                        )))
                                                     ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                     )
                                                    ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                    ))))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                   (SPEC `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                    (conj))
                                                  ) (ASSUME `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                  )
                                                 ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (MP  
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (lemma__ray4)))
                                                ) (MP  
                                                   (SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                    (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                     (or__intror))
                                                   ) (MP  
                                                      (SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                        (or__introl))
                                                      ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                      )))
                                               ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                               )))
                                          ) (MP  
                                             (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))))` 
                                                  (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))` 
                                                        (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                         (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                             (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))` 
                                                              (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))))`
                                               ))
                                             ) (MP  
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (lemma__NCdistinct)))
                                                ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                ))))
                                        ) (MP  
                                           (SPEC `(D : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (lemma__rightangleNC)))
                                           ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                           ))))
                                     ) (SPEC `(D : mat_Point)` 
                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                         (eq__refl))))
                                   ) (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(E : mat_Point)` (lemma__8__2)
                                        ))
                                      ) (ASSUME `((per (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (lemma__collinearright))))
                                      ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      )
                                     ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                     )
                                    ) (ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                    )))
                               ) (MP  
                                  (SPEC `(E : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (lemma__inequalitysymmetric))
                                  ) (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                  )))
                             ) (MP  
                                (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                    (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                     (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                      (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                          (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                             (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                             )))
                                        ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))`
                                  ))
                                ) (MP  
                                   (SPEC `(E : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (lemma__betweennotequal)))
                                   ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                   )))))
                          ) (MP  
                             (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                              (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                 (SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                    (SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                       (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                          (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                           (or__introl))
                                         ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                         )))))))))
                    ) (ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                    ))))
              ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
              ))
            ) (MP  
               (MP  
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` (lemma__extension))))
                ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)
               ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)))
          ) (MP  
             (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
              (MP  
               (MP  
                (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
                ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                   (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                    (MP  
                     (MP  
                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                       (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                         (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                          (MP  
                           (MP  
                            (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                               (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                    (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                     (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                           (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                            (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                            )))
                                       ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                 ))))
                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                           ))))
                     ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                     ))))
               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
               ))
             ) (MP  
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
                ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                ))))
        ) (MP  
           (SPEC `(C : mat_Point)` 
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` (lemma__rightangleNC)))
           ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           )))))))))
 ;;


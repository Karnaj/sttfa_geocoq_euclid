(*lemma__squaresequal :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((cong A) B) a) b) ==> (((((sQ A) B) C) D) ==> (((((sQ a) b) c) d) ==> ((((((((eF A) B) C) D) a) b) c) d)))))))))))`*)
let lemma__squaresequal =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(a : mat_Point)` 
     (GEN `(b : mat_Point)` 
      (GEN `(c : mat_Point)` 
       (GEN `(d : mat_Point)` 
        (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
         (DISCH `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
          (DISCH `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
           (MP  
            (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
               (MP  
                (DISCH `(((((congA (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                 (MP  
                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                   (MP  
                    (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                     (MP  
                      (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                       (MP  
                        (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                         (MP  
                          (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                           (MP  
                            (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (MP  
                              (DISCH `(((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                               (MP  
                                (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                 (MP  
                                  (DISCH `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                   (MP  
                                    (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                         (MP  
                                          (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                           (MP  
                                            (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                               (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                  (DISCH `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((cong__3 (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ m : mat_Point. ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (x : mat_Point)) (d : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ m : mat_Point. ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__paste3
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((eq (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (m : mat_Point))) ((eq (m : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (a : mat_Point)) (m : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (m : mat_Point)) (d : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__squarerectangle
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__squarerectangle
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__congruentequal
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                  ) (
                                                                  ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                  )))
                                                                ) (MP  
                                                                   (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                   )))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                  (MP  
                                                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                 ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(a : mat_Point)` 
                                                                   (SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                               ) (ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                  (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                ) (ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (SPEC `(a : mat_Point)` 
                                                            (SPEC `(d : mat_Point)` 
                                                             (SPEC `(b : mat_Point)` 
                                                              (SPEC `(D : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (axiom__ETsymmetric
                                                                 ))))))
                                                           ) (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                           )))
                                                      ) (MP  
                                                         (DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                             (SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                              (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                               (DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                   (SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                  (DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(d : mat_Point)` 
                                                             (SPEC `(b : mat_Point)` 
                                                              (SPEC `(a : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (axiom__ETpermutation
                                                                  ))))))
                                                            ) (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (SPEC `(d : mat_Point)` 
                                                        (SPEC `(b : mat_Point)` 
                                                         (SPEC `(a : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (axiom__congruentequal
                                                             ))))))
                                                       ) (ASSUME `(((((cong__3 (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                       ))))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point))` 
                                                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                       (conj))
                                                     ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                     )
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                         (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                          (conj))
                                                        ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                       )))))
                                              ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                              ))
                                            ) (MP  
                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                   (SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                    (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                     (DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                         (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                          (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                           (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                            (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(b : mat_Point)` 
                                                   (SPEC `(d : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (lemma__congruenceflip)
                                                     )))
                                                  ) (ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))` 
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `(b : mat_Point)` 
                                                  (SPEC `(d : mat_Point)` 
                                                   (SPEC `(a : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))`
                                                       ))))))
                                                 ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                 )
                                                ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                )
                                               ) (ASSUME `(((((congA (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                               ))
                                             ) (GEN `(A0 : mat_Point)` 
                                                (GEN `(B0 : mat_Point)` 
                                                 (GEN `(C0 : mat_Point)` 
                                                  (GEN `(a0 : mat_Point)` 
                                                   (GEN `(b0 : mat_Point)` 
                                                    (GEN `(c0 : mat_Point)` 
                                                     (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)` 
                                                      (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                       (DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                           (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                            (SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                             (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                              (ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)`
                                                              )))
                                                         ) (MP  
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(c0 : mat_Point)` 
                                                               (SPEC `(b0 : mat_Point)` 
                                                                (SPEC `(a0 : mat_Point)` 
                                                                 (SPEC `(C0 : mat_Point)` 
                                                                  (SPEC `(B0 : mat_Point)` 
                                                                   (SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                              ) (ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)`
                                                              )
                                                             ) (ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                             )
                                                            ) (ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                            ))))))))))))))
                                        ) (MP  
                                           (DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                               (SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))` 
                                                (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                 (DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                     (SPEC `(((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                      (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                       (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                        (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point)))`
                                             ))
                                           ) (MP  
                                              (SPEC `(a : mat_Point)` 
                                               (SPEC `(d : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (lemma__congruenceflip))))
                                              ) (ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (DISCH `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                             (SPEC `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                              (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                               (DISCH `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                   (SPEC `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                    (SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                     (DISCH `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                         (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                          (SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                           (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                            (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))))`
                                           ))
                                         ) (MP  
                                            (SPEC `(d : mat_Point)` 
                                             (SPEC `(c : mat_Point)` 
                                              (SPEC `(b : mat_Point)` 
                                               (SPEC `(a : mat_Point)` 
                                                (lemma__parallelNC))))
                                            ) (ASSUME `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                            ))))
                                    ) (MP  
                                       (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                           (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                  (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                        (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                         ))
                                       ) (MP  
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__parallelNC))))
                                          ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                          ))))
                                  ) (MP  
                                     (CONV_CONV_rule `((((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                      (MP  
                                       (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                        (SPEC `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                         (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                          (DISCH `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                             (MP  
                                              (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                               (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (ASSUME `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                  ))))
                                            ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                            )))))
                                     ) (ASSUME `(((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                     )))
                                ) (MP  
                                   (CONV_CONV_rule `((((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                    (MP  
                                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                       (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                        (DISCH `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                           (MP  
                                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                ))))
                                          ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                          )))))
                                   ) (ASSUME `(((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                   )))
                              ) (MP  
                                 (SPEC `(d : mat_Point)` 
                                  (SPEC `(c : mat_Point)` 
                                   (SPEC `(b : mat_Point)` 
                                    (SPEC `(a : mat_Point)` 
                                     (lemma__squareparallelogram))))
                                 ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                 )))
                            ) (MP  
                               (SPEC `(D : mat_Point)` 
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (lemma__squareparallelogram))))
                               ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                               )))
                          ) (MP  
                             (MP  
                              (SPEC `(a : mat_Point)` 
                               (SPEC `(d : mat_Point)` 
                                (SPEC `(b : mat_Point)` 
                                 (SPEC `(a : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (lemma__congruencetransitive))))))
                              ) (ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                              )
                             ) (ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                             )))
                        ) (MP  
                           (MP  
                            (SPEC `(b : mat_Point)` 
                             (SPEC `(a : mat_Point)` 
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(D : mat_Point)` 
                                  (lemma__congruencetransitive))))))
                            ) (ASSUME `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                            )
                           ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                           )))
                      ) (MP  
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(D : mat_Point)` 
                             (lemma__congruencesymmetric))))
                         ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                         )))
                    ) (MP  
                       (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                        (MP  
                         (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                          (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                           (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                            (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                             (MP  
                              (MP  
                               (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                 (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                  (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                      (SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                       (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                        (DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                            (SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                             (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                              (DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                  (SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                   (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                    (DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                        (SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                         (SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                          (DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                             (MP  
                                                              (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                               (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                   )))))
                                                            ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                    ))))
                              ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                              )))))
                       ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                       )))
                  ) (MP  
                     (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                      (MP  
                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                        (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                         (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                          (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                           (MP  
                            (MP  
                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                              (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                               (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                    (SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                     (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                      (DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                           (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                            (DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                (SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                 (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                  (DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                       (SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                        (DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                           (MP  
                                                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                   (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                 )))))
                                                          ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                  ))))
                            ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                            )))))
                     ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                     )))
                ) (MP  
                   (MP  
                    (SPEC `(b : mat_Point)` 
                     (SPEC `(a : mat_Point)` 
                      (SPEC `(d : mat_Point)` 
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(A : mat_Point)` 
                         (SPEC `(D : mat_Point)` (lemma__Euclid4))))))
                    ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                    )
                   ) (ASSUME `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                   )))
              ) (MP  
                 (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                  (MP  
                   (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                    (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                     (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                      (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                       (MP  
                        (MP  
                         (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                          (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                           (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                            (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                             (MP  
                              (MP  
                               (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                (SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                 (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                  (DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                      (SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                       (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                        (DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                            (SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                             (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                              (DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                  (SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                   (SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                    (DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                       (MP  
                                                        (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                         (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                               (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                             )))))
                                                      ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                      ))))
                                                ) (ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                          ))))
                                    ) (ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                    ))))
                              ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                              ))))
                        ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                        )))))
                 ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                 )))
            ) (MP  
               (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                (MP  
                 (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                   (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                    (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                     (MP  
                      (MP  
                       (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                         (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                          (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                           (MP  
                            (MP  
                             (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                              (SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                               (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                (DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                     (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                      (DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                           (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                            (DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                 (SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                  (DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                     (MP  
                                                      (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                           )))))
                                                    ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                    ))))
                                              ) (ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                            ))))
                      ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                      )))))
               ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
               )))))))))))))
 ;;


(*lemma__parallelPasch :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (((((pG A) B) C) D) ==> ((((betS A) D) E) ==> (ex (\ X : mat_Point. ((mat_and (((betS B) X) E)) (((betS C) X) D))))))))))`*)
let lemma__parallelPasch =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
       (MP  
        (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
         (MP  
          (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (DISCH `(((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
               (MP  
                (DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (MP  
                  (DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                     (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                      (MP  
                       (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                          (DISCH `((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                             (DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                              (MP  
                               (DISCH `((col (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                (MP  
                                 (DISCH `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                    (DISCH `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (MP  
                                        (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                           (DISCH `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                            (MP  
                                             (DISCH `(((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                              (MP  
                                               (CONV_CONV_rule `((((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                (DISCH `ex (\ H18 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H18 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ==> (return : bool))) ==> ((ex (\ H19 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))) ==> (return : bool)))` 
                                                     (SPEC `\ H19 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                                       (ex__ind))))
                                                   ) (GEN `(H19 : mat_Point)` 
                                                      (DISCH `(mat_and (((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                          (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                           (SPEC `((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point)` 
                                                            (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                                                (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point)` 
                                                                  (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (H19 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H19 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearbetween
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H19 : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x11 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x12 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x13 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x13 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((meet (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ p : mat_Point. ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ p : mat_Point. ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ p : mat_Point. ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (D : mat_Point))) ((mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (D : mat_Point))) ((mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (D : mat_Point))) ((mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (D : mat_Point))) ((mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (D : mat_Point))) ((mat_and (((col (p : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (A : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (A : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) ((mat_and (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ p : mat_Point. ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (p : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x11 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x12 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x13 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x13 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point))) ((mat_and (((col (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H19 : mat_Point))) ((mat_and (((col (D : mat_Point)) (H19 : mat_Point)) (C : mat_Point))) ((mat_and (((col (H19 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (H19 : mat_Point)) (D : mat_Point))) (((col (H19 : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H19 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                              ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((betS (B : mat_Point)) (H19 : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H19 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                        ))))
                                                  ) (ASSUME `ex (\ H18 : mat_Point. ((mat_and (((betS (B : mat_Point)) (H18 : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H18 : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)))))`
                                                  )))
                                               ) (ASSUME `(((tS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                               ))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(E : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(D : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (lemma__planeseparation
                                                      )))))
                                                 ) (ASSUME `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                 )
                                                ) (ASSUME `(((tS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                ))))
                                          ) (MP  
                                             (SPEC `(D : mat_Point)` 
                                              (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                               (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__intro))))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                  (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                   (conj))
                                                 ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                 )
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                      (conj))
                                                    ) (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                    )
                                                   ) (ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                   )))))
                                        ) (MP  
                                           (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                               (SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                      (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                       (DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                           (SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__NCorder)))
                                              ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                              (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                    (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                            (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                           ))
                                         ) (MP  
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (lemma__parallelNC))))
                                            ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                            )))))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                                       (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                          (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `(mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                             (SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                              (or__introl))
                                            ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                            )))))
                                 ) (MP  
                                    (DISCH `(mat_and (((col (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                        (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                         (SPEC `((col (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                          (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                               (SPEC `((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                (DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                    (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                     (SPEC `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                      (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                          (SPEC `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                            (DISCH `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                             (ASSUME `((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (D : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (D : mat_Point)))))`
                                      ))
                                    ) (MP  
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (lemma__collinearorder)))
                                       ) (ASSUME `((col (D : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                       ))))
                               ) (MP  
                                  (CONV_CONV_rule `((((nCol (D : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                   (SPEC `(E : mat_Point)` 
                                    (SPEC `(D : mat_Point)` 
                                     (SPEC `(D : mat_Point)` (not__nCol__Col)
                                     )))
                                  ) (DISCH `((nCol (D : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (col__nCol__False)))
                                       ) (ASSUME `((nCol (D : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                       )
                                      ) (MP  
                                         (MP  
                                          (MP  
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (lemma__collinear4))))
                                           ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                           )
                                          ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                          )
                                         ) (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                         )))))))
                            ) (MP  
                               (SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))))` 
                                (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                   (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                      (SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                       (or__intror))
                                     ) (MP  
                                        (SPEC `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                         (SPEC `((betS (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                            (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                             (or__introl))
                                           ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                           ))))))))
                         ) (MP  
                            (SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                             (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                              (or__intror))
                            ) (MP  
                               (SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                   (SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                    (or__introl))
                                  ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                  )))))
                       ) (MP  
                          (DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                              (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                               (SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                    (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                     (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                       (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                       )))
                                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                            ))
                          ) (MP  
                             (SPEC `(E : mat_Point)` 
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (lemma__betweennotequal)))
                             ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                             )))))
                    ) (SPEC `(D : mat_Point)` 
                       (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
                  ) (MP  
                     (DISCH `(mat_and ((((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (SPEC `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                          (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (DISCH `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (SPEC `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (ASSUME `(((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                  )))
                             ) (ASSUME `(mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((((oS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((oS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((oS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                       ))
                     ) (MP  
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(D : mat_Point)` 
                           (SPEC `(C : mat_Point)` (lemma__samesidesymmetric)
                           )))
                        ) (ASSUME `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                        ))))
                ) (MP  
                   (CONV_CONV_rule `((((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                    (MP  
                     (SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                       (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                        (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (SPEC `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                              (DISCH `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (SPEC `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                    (and__ind)))
                                 ) (DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                    (DISCH `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (ASSUME `(((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ((((oS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                          )))))
                   ) (ASSUME `(((tP (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                   )))
              ) (MP  
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(C : mat_Point)` (lemma__paralleldef2B))))
                 ) (ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                 )))
            ) (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__parallelsymmetric))))
               ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
               )))
          ) (MP  
             (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
              (MP  
               (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (and__ind)))
               ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                   ))))
             ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
             )))
        ) (MP  
           (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
            (MP  
             (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
              (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (and__ind)))
             ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                 ))))
           ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
           )))))))))
 ;;


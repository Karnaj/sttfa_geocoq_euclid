(*lemma__rectangleparallelogram :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((rE A) B) C) D) ==> ((((pG A) B) C) D)))))`*)
let lemma__rectangleparallelogram =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
       (MP  
        (DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
         (MP  
          (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
             (MP  
              (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(M : mat_Point)` 
                    (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                         (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                          (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                           (MP  
                            (MP  
                             (SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                               (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                     (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                           (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `(((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                     (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                      (MP  
                                                       (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                              (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                 (DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (A : mat_Point)) (x : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (A : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (A : mat_Point)) (V : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (D : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((neq (B : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (x : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))))))))) ==> (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (B : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((neq (B : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (P : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (B : mat_Point)) (P : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not (((per (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (P : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((per (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__8__7
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (P : mat_Point))) ==> ((neq (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (P : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (C : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (C : mat_Point))) (((col (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (D : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (D : mat_Point))) (((col (P : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> ((neq (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (P : mat_Point)) ==> (((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((eq (B : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((rE (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((per (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((per (P : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (P : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((nCol (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((((col (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((eq (P : mat_Point)) (P : mat_Point)) ==> ((((col (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> ((((betS (D : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> (((((par (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (D : mat_Point)) (P : mat_Point)) (C : mat_Point)) ==> (((neq (P : mat_Point)) (C : mat_Point)) ==> ((((col (P : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> (((((rE (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((per (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((per (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((nCol (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> ((((betS (D : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((par (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (D : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (D : mat_Point)) (x : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((rE (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((per (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((per (B0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((nCol (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((betS (B0 : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (B0 : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) ==> (((eq (B0 : mat_Point)) (B0 : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) ==> ((((betS (D : mat_Point)) (M : mat_Point)) (B0 : mat_Point)) ==> (((((par (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (D : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((neq (B0 : mat_Point)) (C : mat_Point)) ==> ((((col (B0 : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (D : mat_Point)) (B0 : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((rE (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (D : mat_Point)) (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (P : mat_Point)) ==> (((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (((eq (A : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((rE (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((per (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((((cR (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((nCol (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((meet (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (P : mat_Point)) (B : mat_Point)) ==> (((eq (P : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((par (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (P : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (P : mat_Point)) (D : mat_Point)) ==> ((((col (P : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> (((((rE (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((per (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cR (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((meet (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((par (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (x : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (x : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (x : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. (((((rE (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> ((((per (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((cR (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> ((((betS (A0 : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((mat_not ((((meet (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A0 : mat_Point)) (B : mat_Point)) ==> (((eq (A0 : mat_Point)) (A0 : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((par (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((meet (A0 : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (A0 : mat_Point)) (D : mat_Point)) ==> ((((col (A0 : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (A0 : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((rE (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (P : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (P : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (P : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((neq (A : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (A : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (A : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x : mat_Point)) (X : mat_Point)) (B : mat_Point)))))))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (B : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (B : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (D : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (x : mat_Point))) (((betS (D : mat_Point)) (X : mat_Point)) (B : mat_Point)))))))))))))) ==> (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (D : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (D : mat_Point)) (X : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (D : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (D : mat_Point)) (X : mat_Point)) (B : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (x : mat_Point)) (B : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (X : mat_Point)) (B : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (X : mat_Point)) (B : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                   ) (
                                                                   SPEC `(B : mat_Point)` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                   ))))
                                                                ) (MP  
                                                                   (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                   )))))
                                                             ) (SPEC `(A : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__refl)))
                                                            )
                                                           ) (MP  
                                                              (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                                   (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                 ) (ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                 ))))
                                                         ) (MP  
                                                            (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                (SPEC `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                                 (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                                                              ))
                                                            ) (MP  
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (lemma__NCdistinct
                                                                  )))
                                                               ) (ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                               ))))
                                                       ) (MP  
                                                          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                            ))
                                                          ) (MP  
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (lemma__NCdistinct
                                                                )))
                                                             ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                             )))))
                                                    ) (DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                         (DISCH `ex (\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `mat_false` 
                                                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))))) ==> (return : bool)))` 
                                                              (SPEC `\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)))))` 
                                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                                (ex__ind))))
                                                            ) (GEN `(P : mat_Point)` 
                                                               (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `mat_false` 
                                                                   (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (P : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (D : mat_Point)) (P : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (D : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not (((per (P : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (P : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((per (P : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__8__7
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (D : mat_Point)) (P : mat_Point))) ==> ((neq (P : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (D : mat_Point)) (P : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearright
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> ((neq (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (P : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (P : mat_Point)) ==> (((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) ==> (((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> ((((per (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> ((((per (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> (((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((neq (C : mat_Point)) (P : mat_Point)) ==> ((((col (C : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> (((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((per (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> ((((col (C : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ D0 : mat_Point. (((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) ==> ((((per (D0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (B : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) ==> ((((per (C : mat_Point)) (D0 : mat_Point)) (A : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) ==> ((((nCol (D0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (D0 : mat_Point)) (A : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (D0 : mat_Point)) ==> (((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) ==> (((neq (C : mat_Point)) (D0 : mat_Point)) ==> ((((col (C : mat_Point)) (D0 : mat_Point)) (P : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (D0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (P : mat_Point)) ==> (((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> ((((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> (((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((rE (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((per (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((((cR (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> ((((nCol (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> (((((meet (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (P : mat_Point)) (B : mat_Point)) ==> ((((col (P : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> (((((rE (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((per (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((((cR (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> (((((meet (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. (((((rE (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((per (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> ((((per (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> (((((cR (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((nCol (D : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point)) ==> ((((betS (A0 : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> (((((meet (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (A0 : mat_Point)) (B : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (A0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((rE (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (P : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (P : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `ex (\ P : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point))))))`
                                                           )))
                                                        ) (ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                        ))))))
                                              ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                            ))))
                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
                ))
              ) (MP  
                 (CONV_CONV_rule `((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))) ==> (ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))))` 
                  (MP  
                   (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                    (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))` 
                     (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                      (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))` 
                       (MP  
                        (MP  
                         (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                          (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                           (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                             (MP  
                              (MP  
                               (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                                (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                 (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                                      (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                       (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                        (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                         (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))`
                                         )))
                                    ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))`
                                    ))))
                              ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))`
                              ))))
                        ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))`
                        )))))
                 ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                 )))
            ) (MP  
               (MP  
                (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                 (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                  (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                   (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                    (MP  
                     (MP  
                      (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                       (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                        (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                          (MP  
                           (MP  
                            (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                             (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                              (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                (MP  
                                 (MP  
                                  (SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                   (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                    (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                     (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                      (MP  
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (lemma__rightangleNC)))
                                       ) (ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                       ))))
                                 ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                 ))))
                           ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                           ))))
                     ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                     ))))
               ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
               )))
          ) (MP  
             (MP  
              (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
               (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                 (and__ind)))
              ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                 (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                  (MP  
                   (MP  
                    (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                      (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                        (MP  
                         (MP  
                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                            (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                              (MP  
                               (MP  
                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                  (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                   (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                    (MP  
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__rightangleNC)))
                                     ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     ))))
                               ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                               ))))
                         ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                         ))))
                   ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                   ))))
             ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
             )))
        ) (MP  
           (MP  
            (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
             (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
              (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
               (and__ind)))
            ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
               (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                (MP  
                 (MP  
                  (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                   (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                    (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                         (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                          (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                               (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                 (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(D : mat_Point)` 
                                      (lemma__rightangleNC)))
                                   ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                   ))))
                             ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                       ))))
                 ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                 ))))
           ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
           )))
      ) (MP  
         (CONV_CONV_rule `((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))` 
          (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
           (MP  
            (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
             (MP  
              (MP  
               (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                 (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                      (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                       (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                            (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                             (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                  (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                   (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                    (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                        (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (conj))
                                       ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                       )
                                      ) (MP  
                                         (MP  
                                          (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                           (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (conj))
                                          ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                          )
                                         ) (MP  
                                            (MP  
                                             (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                              (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (conj))
                                             ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (MP  
                                               (MP  
                                                (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (conj))
                                                ) (ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                )
                                               ) (ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                               )))))))
                                ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                          ))))
                    ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                    ))))
              ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
              ))
            ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
            )))
         ) (ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


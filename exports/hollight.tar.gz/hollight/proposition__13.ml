(*proposition__13 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. ((((betS D) B) C) ==> ((((nCol A) B) C) ==> ((((((rT C) B) A) A) B) D))))))`*)
let proposition__13 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (MP  
       (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
        (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
         (MP  
          (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
           (MP  
            (DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
             (MP  
              (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
               (MP  
                (CONV_CONV_rule `((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> ((((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                 (DISCH `((((supp (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                  (MP  
                   (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                    (MP  
                     (CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                      (DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                           (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> ((((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                              (DISCH `((col (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                               (MP  
                                (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                 (MP  
                                  (DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                   (MP  
                                    (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                       (MP  
                                        (DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> ((((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                           (DISCH `(((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                            (ASSUME `(((((rT (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                            ))
                                          ) (MP  
                                             (SPEC `(C : mat_Point)` 
                                              (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))))` 
                                               (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__intro))))
                                             ) (MP  
                                                (SPEC `(B : mat_Point)` 
                                                 (CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (x : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (x : mat_Point)) (Z : mat_Point)))))))))) ==> (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                  (SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__intro))))
                                                ) (MP  
                                                   (SPEC `(D : mat_Point)` 
                                                    (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (x : mat_Point)))))))) ==> (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (Z : mat_Point)))))))))))` 
                                                     (SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (Z : mat_Point))))))))` 
                                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                                       (ex__intro))))
                                                   ) (MP  
                                                      (SPEC `(A : mat_Point)` 
                                                       (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (D : mat_Point)))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (U : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))` 
                                                        (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (U : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (D : mat_Point))))))` 
                                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                                          (ex__intro))))
                                                      ) (MP  
                                                         (SPEC `(A : mat_Point)` 
                                                          (CONV_CONV_rule `! x : mat_Point. (((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ==> (ex (\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))` 
                                                           (SPEC `\ V : mat_Point. ((mat_and (((((supp (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (V : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (ex__intro))))
                                                         ) (MP  
                                                            (MP  
                                                             (SPEC `(mat_and ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                              (SPEC `((((supp (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                               (conj))
                                                             ) (ASSUME `((((supp (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                             )
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (conj))
                                                                ) (ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                               )))))))))
                                        ) (MP  
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (lemma__equalanglesreflexive)))
                                           ) (ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                           )))
                                      ) (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__equalanglesreflexive)))
                                         ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                         )))
                                    ) (MP  
                                       (DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                           (SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                            (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                             (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                  (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                        (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                         (DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                              (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                                         ))
                                       ) (MP  
                                          (SPEC `(A : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (lemma__NCorder)))
                                          ) (ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                          ))))
                                  ) (MP  
                                     (SPEC `(A : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(D : mat_Point)` (nCol__notCol)
                                       ))
                                     ) (MP  
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (nCol__not__Col)))
                                        ) (MP  
                                           (MP  
                                            (MP  
                                             (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (lemma__NChelper)))))
                                              ) (ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                              )
                                             ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                            )
                                           ) (ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                           )))))
                                ) (MP  
                                   (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                       (SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                             (SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                               (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                (ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                )))
                                           ) (ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))`
                                     ))
                                   ) (MP  
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(D : mat_Point)` 
                                         (lemma__betweennotequal)))
                                      ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                      )))))
                             ) (MP  
                                (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                 (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                    (SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                       (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                      ))))))
                          ) (SPEC `(B : mat_Point)` 
                             (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
                        ) (MP  
                           (DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                               (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                (SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                     (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                      (SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                       (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                           (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                            (SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                    (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                             ))
                           ) (MP  
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(D : mat_Point)` 
                                 (lemma__collinearorder)))
                              ) (ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                              )))))
                     ) (MP  
                        (SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                         (SPEC `(eq (D : mat_Point)) (B : mat_Point)` 
                          (or__intror))
                        ) (MP  
                           (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                            (SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                             (or__intror))
                           ) (MP  
                              (SPEC `(mat_or (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                               (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `(mat_or (((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                  (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                   (or__intror))
                                 ) (MP  
                                    (SPEC `((betS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                     (SPEC `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (or__introl))
                                    ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )))))))
                   ) (MP  
                      (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                          (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                           (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                            (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                 (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                  (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                      (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                       (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                            (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                             (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                        ))
                      ) (MP  
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__NCorder)))
                         ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                         )))))
                ) (MP  
                   (MP  
                    (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                     (SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                      (conj))
                    ) (ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                    )
                   ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                   )))
              ) (MP  
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(D : mat_Point)` (axiom__betweennesssymmetry)))
                 ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))
            ) (MP  
               (MP  
                (SPEC `(A : mat_Point)` 
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(B : mat_Point)` (lemma__ray4)))
                ) (MP  
                   (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                    (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                     (or__intror))
                   ) (MP  
                      (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                       (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                        (or__introl))
                      ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`)))
               ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`)))
          ) (MP  
             (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
              (MP  
               (MP  
                (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                 (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                  (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
                ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                   (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                    (MP  
                     (MP  
                      (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                       (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                         (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                          (MP  
                           (MP  
                            (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                             (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                               (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                   (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                    (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                     (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                         (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                           (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                            (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                            )))
                                       ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                 ))))
                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                           ))))
                     ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                     ))))
               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
               ))
             ) (MP  
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
                ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                )))))
       ) (SPEC `(A : mat_Point)` (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))
      ))))))
 ;;

